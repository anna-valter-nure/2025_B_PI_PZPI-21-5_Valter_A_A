﻿namespace Application.Users.Commands.CreateUser;

public sealed class CreateUserCommandProfile : AutoMapper.Profile
{
    public CreateUserCommandProfile()
    {
        CreateMap<CreateUserCommand, User>();
    }
}