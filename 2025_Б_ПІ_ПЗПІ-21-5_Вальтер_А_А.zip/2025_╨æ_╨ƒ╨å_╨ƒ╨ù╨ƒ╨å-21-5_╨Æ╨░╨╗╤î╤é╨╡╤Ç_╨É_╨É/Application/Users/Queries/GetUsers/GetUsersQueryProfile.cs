namespace Application.Users.Queries.GetUsers;

public sealed class GetUsersQueryProfile : AutoMapper.Profile
{
    public GetUsersQueryProfile()
    {
        CreateMap<User, UsersResponse>();
    }
}
