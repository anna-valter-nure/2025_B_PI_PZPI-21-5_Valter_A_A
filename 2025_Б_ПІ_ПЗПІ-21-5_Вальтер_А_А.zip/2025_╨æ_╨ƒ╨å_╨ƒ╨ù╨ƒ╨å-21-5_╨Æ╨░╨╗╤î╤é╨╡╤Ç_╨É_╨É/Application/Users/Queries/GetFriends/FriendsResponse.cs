using Domain.Enums;

namespace Application.Users.Queries.GetFriends;

public record FriendsResponse(
    Guid Id,
    string Name,
    string Email,
    InvitationStatus Status,
    bool IsSender
    )
{
    public FriendsResponse()
        : this(Guid.Empty, string.Empty, string.Empty, InvitationStatus.Accepted, false)
    {
    }
};
