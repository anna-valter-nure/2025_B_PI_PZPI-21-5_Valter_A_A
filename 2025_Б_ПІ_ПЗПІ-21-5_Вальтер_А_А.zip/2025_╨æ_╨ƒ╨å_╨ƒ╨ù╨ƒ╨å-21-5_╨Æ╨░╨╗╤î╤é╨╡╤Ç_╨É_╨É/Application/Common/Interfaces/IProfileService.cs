namespace Application.Common.Interfaces;

public interface IProfileService
{
    Task ChangeProfileVisibilityAsync(CancellationToken cancellationToken);

    Task<User> GetProfileAsync(string requestEmail, CancellationToken cancellationToken);

    Task UpdateProfileAsync(User user, CancellationToken cancellationToken);
}
