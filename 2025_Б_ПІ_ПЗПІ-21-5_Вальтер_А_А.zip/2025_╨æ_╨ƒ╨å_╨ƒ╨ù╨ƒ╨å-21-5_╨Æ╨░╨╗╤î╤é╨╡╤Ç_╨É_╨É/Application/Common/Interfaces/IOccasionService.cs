namespace Application.Common.Interfaces;

public interface IOccasionService
{
    Task CreateOccasionAsync(Occasion occasion, CancellationToken cancellationToken);

    Task DeleteOccasionAsync(Guid id, CancellationToken cancellationToken);

    Task UpdateOccasionAsync(Occasion occasion, CancellationToken cancellationToken);

    Task<(IEnumerable<Occasion>, int totalPages)> GetOccasionsByEmailAsync(
        int pageNumber,
        int pageSize,
        CancellationToken cancellationToken);

    Task<Occasion> GetOccasionsByIdAsync(Guid id, CancellationToken cancellationToken);
}
