namespace Application.Common.Interfaces;

public interface IExceptionLocalizer
{
    string GetMessage(string key);
}
