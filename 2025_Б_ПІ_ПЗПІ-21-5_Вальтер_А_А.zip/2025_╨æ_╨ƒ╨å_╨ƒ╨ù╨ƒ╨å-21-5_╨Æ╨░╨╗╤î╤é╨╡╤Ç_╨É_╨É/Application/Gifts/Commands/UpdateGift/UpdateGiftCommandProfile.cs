namespace Application.Gifts.Commands.UpdateGift;

public sealed class UpdateGiftCommandProfile : AutoMapper.Profile
{
    public UpdateGiftCommandProfile()
    {
        CreateMap<UpdateGiftCommand, Gift>();
    }
}