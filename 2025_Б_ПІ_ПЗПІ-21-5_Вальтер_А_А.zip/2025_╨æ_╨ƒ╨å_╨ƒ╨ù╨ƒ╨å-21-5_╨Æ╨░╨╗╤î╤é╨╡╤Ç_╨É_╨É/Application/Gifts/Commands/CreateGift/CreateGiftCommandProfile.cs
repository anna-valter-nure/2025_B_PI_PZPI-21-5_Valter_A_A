﻿namespace Application.Gifts.Commands.CreateGift;

public sealed class CreateGiftCommandProfile : AutoMapper.Profile
{
    public CreateGiftCommandProfile()
    {
        CreateMap<CreateGiftCommand, Gift>();
    }
}