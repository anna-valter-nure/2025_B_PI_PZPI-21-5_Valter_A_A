namespace Application.Wishlists.Commands.CreateWishlist;

public sealed class CreateWishlistCommandProfile : AutoMapper.Profile
{
    public CreateWishlistCommandProfile()
    {
        CreateMap<CreateWishlistCommand, Wishlist>();
    }
}
