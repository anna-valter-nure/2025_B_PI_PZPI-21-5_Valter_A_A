namespace Application.Wishlists.Commands.UpdateWishlist;

public sealed class UpdateWishlistCommandProfile : AutoMapper.Profile
{
    public UpdateWishlistCommandProfile()
    {
        CreateMap<UpdateWishlistCommand, Wishlist>();
    }
}
