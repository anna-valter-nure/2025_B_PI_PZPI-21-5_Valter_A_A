using Application.Common.Models;
using Application.Gifts.Queries;

namespace Application.Wishlists.Queries.GetWishlist;

public record WishlistResponse
{
    public required string Name { get; set; }
    public required List<string> CategoryNames { get; set; }
    public DateTimeOffset OccasionDate { get; set; }
    public required PageResponse<GiftResponse> Gifts { get; set; } = null!;
    public required string CreatedBy { get; set; }
}
