namespace Application.Profile.Queries.GetOccasionsByEmail;

public class GetOccasionsByEmailQueryProfile : AutoMapper.Profile
{
    public GetOccasionsByEmailQueryProfile()
    {
        CreateMap<Occasion, OccasionResponse>();
    }
}
