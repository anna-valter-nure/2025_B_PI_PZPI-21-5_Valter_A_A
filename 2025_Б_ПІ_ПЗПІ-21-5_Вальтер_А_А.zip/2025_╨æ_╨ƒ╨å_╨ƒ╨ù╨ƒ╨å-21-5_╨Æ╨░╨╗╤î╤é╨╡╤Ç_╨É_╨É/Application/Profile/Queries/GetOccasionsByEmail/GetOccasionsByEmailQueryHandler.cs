using Application.Common.Models;

namespace Application.Profile.Queries.GetOccasionsByEmail;

public class GetOccasionsByEmailQueryHandler(IOccasionService occasionService, IMapper mapper)
    : IRequestHandler<GetOccasionsByEmailQuery, PageResponse<OccasionResponse>>
{
    public async Task<PageResponse<OccasionResponse>> Handle(GetOccasionsByEmailQuery request, CancellationToken cancellationToken)
    {
        var (occasions, totalPages) = await occasionService.GetOccasionsByEmailAsync(
            request.PageNumber,
            request.PageSize,
            cancellationToken);

        var mappedOccasions = mapper.Map<IEnumerable<OccasionResponse>>(occasions);

        return new PageResponse<OccasionResponse>(
            mappedOccasions,
            request.PageNumber,
            request.PageSize,
            totalPages);
    }
}
