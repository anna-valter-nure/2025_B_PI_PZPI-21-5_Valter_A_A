using Application.Common.Models;

namespace Application.Profile.Queries.GetOccasionsByEmail;

public record GetOccasionsByEmailQuery() : PageRequest<PageResponse<OccasionResponse>>;
