namespace Application.Profile.Queries.GetOccasionsByEmail;

public record OccasionResponse(Guid Id, string Name, DateTime Date)
{
    public OccasionResponse()
        : this(Guid.Empty, string.Empty, DateTime.Now)
    {
    }
}
