using Application.Profile.Queries.GetOccasionsByEmail;

namespace Application.Profile.Queries.GetOccasionById;

public record GetOccasionByIdQuery(Guid Id) : IRequest<OccasionResponse>;
