﻿namespace Application.Profile.Queries.GetProfile;

public record GetProfileQuery(string Email) : IRequest<Profile>;
