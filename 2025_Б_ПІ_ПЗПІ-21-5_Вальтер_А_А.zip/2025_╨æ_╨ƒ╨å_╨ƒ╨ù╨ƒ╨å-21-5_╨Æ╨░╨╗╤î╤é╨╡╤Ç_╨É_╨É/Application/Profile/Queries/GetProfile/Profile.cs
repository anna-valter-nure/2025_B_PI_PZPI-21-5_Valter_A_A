﻿using Domain.Enums;

namespace Application.Profile.Queries.GetProfile;

public class Profile
{
    public required string Name { get; set; }

    public string? Bio { get; set; }

    public Gender Gender { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public string? Hobby { get; set; }

    public string? ClothingSize { get; set; }

    public string? ShoeSize { get; set; }

    public string? RingSize { get; set; }

    public string? FavoriteColor { get; set; }

    public bool IsPublic { get; set; }

    public bool AllowFriendRequests { get; set; }

    public bool ShowBirthday { get; set; }

    private sealed class MappingProfile : AutoMapper.Profile
    {
        public MappingProfile()
        {
            CreateMap<User, Profile>();
        }
    }
};
