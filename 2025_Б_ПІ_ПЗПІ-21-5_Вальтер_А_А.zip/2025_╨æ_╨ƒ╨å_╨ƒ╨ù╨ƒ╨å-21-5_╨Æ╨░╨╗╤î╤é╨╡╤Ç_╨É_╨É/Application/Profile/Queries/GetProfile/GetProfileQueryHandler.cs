﻿namespace Application.Profile.Queries.GetProfile;

public sealed class GetProfileQueryHandler(IProfileService profileService, IMapper mapper)
    : IRequestHandler<GetProfileQuery, Profile>
{
    public async Task<Profile> Handle(GetProfileQuery request, CancellationToken cancellationToken)
    {
        var user = await profileService.GetProfileAsync(request.Email, cancellationToken);
        return mapper.Map<Profile>(user);
    }
}
