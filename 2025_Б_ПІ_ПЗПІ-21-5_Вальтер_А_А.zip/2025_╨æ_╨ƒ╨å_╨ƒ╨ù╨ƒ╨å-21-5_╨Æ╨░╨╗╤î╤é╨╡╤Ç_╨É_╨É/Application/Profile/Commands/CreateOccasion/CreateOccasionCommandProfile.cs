namespace Application.Profile.Commands.CreateOccasion;

public sealed class CreateOccasionCommandProfile : AutoMapper.Profile
{
    public CreateOccasionCommandProfile()
    {
        CreateMap<CreateOccasionCommand, Occasion>();
    }
}
