namespace Application.Profile.Commands.CreateOccasion;

public record CreateOccasionCommand(string Name, DateTime Date) : IRequest<Unit>;
