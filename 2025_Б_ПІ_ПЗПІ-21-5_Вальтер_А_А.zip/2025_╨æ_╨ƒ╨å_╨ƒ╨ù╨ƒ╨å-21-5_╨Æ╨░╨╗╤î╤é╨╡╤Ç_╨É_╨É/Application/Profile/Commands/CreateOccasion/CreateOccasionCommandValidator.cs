namespace Application.Profile.Commands.CreateOccasion;

public class CreateOccasionCommandValidator : AbstractValidator<CreateOccasionCommand>
{
    public CreateOccasionCommandValidator()
    {
        RuleFor(d => d.Name).NotEmpty().WithMessage("Name is required.");
        RuleFor(d => d.Date)
            .NotEmpty()
            .WithMessage("Date is required.")
            .GreaterThan(DateTime.Now)
            .WithMessage("Occasion must be in future.");
    }
}
