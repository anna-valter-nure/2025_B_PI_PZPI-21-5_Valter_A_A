namespace Application.Profile.Commands.CreateOccasion;

public class CreateOccasionCommandHandler(IOccasionService occasionService, IMapper mapper) : IRequestHandler<CreateOccasionCommand, Unit>
{
    public async Task<Unit> Handle(CreateOccasionCommand request, CancellationToken cancellationToken)
    {
        var occasion = mapper.Map<Occasion>(request);
        await occasionService.CreateOccasionAsync(occasion, cancellationToken);

        return Unit.Value;
    }
}
