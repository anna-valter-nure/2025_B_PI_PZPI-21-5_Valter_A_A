namespace Application.Profile.Commands.UpdateOccasion;

public record UpdateOccasionCommand(Guid Id, string Name, DateTime Date) : IRequest<Unit>;
