namespace Application.Profile.Commands.UpdateOccasion;

public class UpdateOccasionCommandProfile : AutoMapper.Profile
{
    public UpdateOccasionCommandProfile()
    {
        CreateMap<UpdateOccasionCommand, Occasion>();
    }
}
