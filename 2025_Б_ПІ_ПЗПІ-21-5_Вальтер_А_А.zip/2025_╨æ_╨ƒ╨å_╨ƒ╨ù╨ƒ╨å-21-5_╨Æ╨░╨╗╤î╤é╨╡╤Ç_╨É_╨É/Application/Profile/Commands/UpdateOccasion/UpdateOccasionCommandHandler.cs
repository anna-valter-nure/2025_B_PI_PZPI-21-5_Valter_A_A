namespace Application.Profile.Commands.UpdateOccasion;

public class UpdateOccasionCommandHandler(IOccasionService occasionService, IMapper mapper)
    : IRequestHandler<UpdateOccasionCommand, Unit>
{
    public async Task<Unit> Handle(UpdateOccasionCommand request, CancellationToken cancellationToken)
    {
        var occasion = mapper.Map<Occasion>(request);
        await occasionService.UpdateOccasionAsync(occasion, cancellationToken);

        return Unit.Value;
    }
}
