namespace Application.Profile.Commands.ChangeProfileVisibility;

public class ChangeProfileVisibilityCommandHandler(IProfileService profileService, IMapper mapper)
    : IRequestHandler<ChangeProfileVisibilityCommand, Unit>
{
    public async Task<Unit> Handle(ChangeProfileVisibilityCommand request, CancellationToken cancellationToken)
    {
        await profileService.ChangeProfileVisibilityAsync(cancellationToken);

        return Unit.Value;
    }
}
