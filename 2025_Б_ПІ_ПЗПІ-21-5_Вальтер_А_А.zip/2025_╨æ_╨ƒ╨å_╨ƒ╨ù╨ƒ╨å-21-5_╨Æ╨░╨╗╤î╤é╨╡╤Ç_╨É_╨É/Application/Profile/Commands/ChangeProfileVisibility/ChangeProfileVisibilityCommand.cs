namespace Application.Profile.Commands.ChangeProfileVisibility;

public record ChangeProfileVisibilityCommand() : IRequest<Unit>;
