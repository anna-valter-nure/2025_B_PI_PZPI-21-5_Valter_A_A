﻿namespace Application.Profile.Commands.UpdateProfile;

public class UpdateProfileCommandProfile : AutoMapper.Profile
{
    public UpdateProfileCommandProfile()
    {
        CreateMap<UpdateProfileCommand, User>();
    }
}