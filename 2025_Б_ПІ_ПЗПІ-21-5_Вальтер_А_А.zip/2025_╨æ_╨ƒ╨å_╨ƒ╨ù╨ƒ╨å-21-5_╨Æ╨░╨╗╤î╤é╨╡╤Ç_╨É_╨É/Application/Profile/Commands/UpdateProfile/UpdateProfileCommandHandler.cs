﻿namespace Application.Profile.Commands.UpdateProfile;

public class UpdateProfileCommandHandler(IProfileService profileService, IMapper mapper) : IRequestHandler<UpdateProfileCommand, Unit>
{
    public async Task<Unit> Handle(UpdateProfileCommand request, CancellationToken cancellationToken)
    {
        var user = mapper.Map<User>(request);

        await profileService.UpdateProfileAsync(user, cancellationToken);

        return Unit.Value;
    }
}