﻿using Domain.Enums;

namespace Application.Profile.Commands.UpdateProfile;

public record UpdateProfileCommand(string? Name, string? Bio, string? AvatarUrl, Gender Gender, DateTime? DateOfBirth, string? Hobby) : IRequest<Unit>;