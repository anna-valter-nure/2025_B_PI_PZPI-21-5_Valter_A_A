namespace Application.Profile.Commands.DeleteOccasion;

public class DeleteOccasionCommandHandler(IOccasionService occasionService) : IRequestHandler<DeleteOccasionCommand, Unit>
{
    public async Task<Unit> Handle(DeleteOccasionCommand request, CancellationToken cancellationToken)
    {
        await occasionService.DeleteOccasionAsync(request.Id, cancellationToken);
        return Unit.Value;
    }
}
