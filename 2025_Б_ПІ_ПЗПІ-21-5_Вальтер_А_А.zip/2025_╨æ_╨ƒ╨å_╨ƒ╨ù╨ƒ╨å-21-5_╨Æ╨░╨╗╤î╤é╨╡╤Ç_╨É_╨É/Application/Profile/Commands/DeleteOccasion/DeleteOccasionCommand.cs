namespace Application.Profile.Commands.DeleteOccasion;

public record DeleteOccasionCommand(Guid Id) : IRequest<Unit>;

