﻿// Global using directives

global using Application.Common.Interfaces;
global using AutoMapper;
global using Domain.Entities;
global using FluentValidation;
global using MediatR;