﻿// Global using directives

global using Microsoft.AspNetCore.Authorization;
global using Microsoft.AspNetCore.Mvc;