import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-WNPUX6EK.js";
import "./chunk-BGKFPO4M.js";
import "./chunk-R6AJMFYL.js";
import "./chunk-WBS44QWF.js";
import "./chunk-ML7BWUGJ.js";
import "./chunk-WAZ2ZTVE.js";
import "./chunk-RP3SPLOW.js";
import "./chunk-VWEI3PJ6.js";
import "./chunk-OCY53FXS.js";
import "./chunk-NBIKOIY3.js";
import "./chunk-EIPUYNJK.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
