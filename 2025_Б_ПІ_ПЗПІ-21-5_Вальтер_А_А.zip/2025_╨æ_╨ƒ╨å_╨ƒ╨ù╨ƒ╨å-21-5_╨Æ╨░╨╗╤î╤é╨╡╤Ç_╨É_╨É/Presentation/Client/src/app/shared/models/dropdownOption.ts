export interface DropdownOption {
  value: string | number | boolean | null;
  text: string;
}

export interface DropdownOptionWithDefinition extends DropdownOption {
  definition: string;
}
