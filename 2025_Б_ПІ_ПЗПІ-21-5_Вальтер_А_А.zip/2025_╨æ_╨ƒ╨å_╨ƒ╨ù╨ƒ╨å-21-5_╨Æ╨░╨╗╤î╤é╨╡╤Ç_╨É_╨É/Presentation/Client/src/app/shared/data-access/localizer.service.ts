import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { all as locales } from 'primelocale';
import { PrimeNG } from 'primeng/config';
import { Observable } from 'rxjs';
import { DropdownOption } from '../models/dropdownOption';

@Injectable({
  providedIn: 'root',
})
export class LocalizerService {
  constructor(
    private translate: TranslateService,
    private primeNg: PrimeNG,
  ) {}

  getSupportedLanguagesDropdownOptions(): DropdownOption[] {
    return [
      { value: 'en', text: 'English' },
      { value: 'uk', text: 'Українська' },
    ];
  }

  getLocalizedString(key: string, params?: any): Observable<any> {
    return this.translate.get(key, params);
  }

  changeLanguage(language: string): void {
    localStorage.setItem('language', language);
    this.translate.use(language);

    switch (language) {
      case 'en':
        this.primeNg.setTranslation(locales['en']);
        break;
      case 'uk':
        this.primeNg.setTranslation(locales['uk']);
        break;
      default:
        this.primeNg.setTranslation(locales['en']);
        break;
    }
  }

  getCurrentLanguage(): string {
    const language = localStorage.getItem('language');
    return language || this.translate.getDefaultLang();
  }
}
