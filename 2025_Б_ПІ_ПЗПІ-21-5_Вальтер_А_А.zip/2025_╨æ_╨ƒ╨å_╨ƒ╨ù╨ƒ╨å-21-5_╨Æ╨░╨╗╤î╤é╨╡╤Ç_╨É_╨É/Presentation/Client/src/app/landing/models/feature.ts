export interface Feature {
  title: string;
  description: string;
  icon?: string;
}

export interface Testimonial {
  name: string;
  quote: string;
  title: string;
}

export const appFeatures: Feature[] = [
  {
    title: 'landing.createPersonalWishlists',
    description: 'landing.createPersonalWishlistsDescription',
    icon: 'pi pi-gift text-3xl! text-marmelade-500',
  },
  {
    title: 'landing.guestBrowsing',
    description: 'landing.guestBrowsingDescription',
    icon: 'pi pi-users text-3xl! text-shark-500',
  },
  {
    title: 'landing.shareWithFriends',
    description: 'landing.shareWithFriendsDescription',
    icon: 'pi pi-share-alt text-3xl! text-marmelade-500',
  },
  {
    title: 'landing.filterByEvent',
    description: 'landing.filterByEventDescription',
    icon: 'pi pi-search text-3xl! text-shark-500',
  },
  {
    title: 'landing.saveFavorites',
    description: 'landing.saveFavoritesDescription',
    icon: 'pi pi-star text-3xl! text-marmelade-500',
  },
  {
    title: 'landing.eventOrganization',
    description: 'landing.eventOrganizationDescription',
    icon: 'pi pi-calendar text-3xl! text-shark-500',
  },
];

export const wishlistCreationSteps: Feature[] = [
  {
    title: 'landing.createAccount',
    description: 'landing.createAccountDescription',
  },
  {
    title: 'landing.addYourWishes',
    description: 'landing.addYourWishesDescription',
  },
  {
    title: 'landing.shareAndDiscover',
    description: 'landing.shareAndDiscoverDescription',
  },
];

export const appTestimonials: Testimonial[] = [
  {
    name: 'landing.sarahJ',
    quote: 'landing.sarahJQuote',
    title: 'landing.sarahJTitle',
  },
  {
    name: 'landing.michaelT',
    quote: 'landing.michaelTQuote',
    title: 'landing.michaelTTitle',
  },
  {
    name: 'landing.jessicaK',
    quote: 'landing.jessicaKQuote',
    title: 'landing.jessicaKTitle',
  },
];
