import { Component, OnInit } from '@angular/core';
import { LocalizerService } from '../../../shared/data-access/localizer.service';
import { DropdownOption } from '../../../shared/models/dropdownOption';
import {
  appFeatures,
  appTestimonials,
  Feature,
  Testimonial,
  wishlistCreationSteps,
} from '../../models/feature';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  standalone: false,
})
export class LandingComponent implements OnInit {
  currentLanguage: string = '';
  languageOptions: DropdownOption[] = [];
  features: Feature[] = appFeatures;
  steps: Feature[] = wishlistCreationSteps;
  testimonials: Testimonial[] = appTestimonials;

  constructor(public localizer: LocalizerService) {}

  ngOnInit() {
    this.currentLanguage = this.localizer.getCurrentLanguage();
    this.languageOptions =
      this.localizer.getSupportedLanguagesDropdownOptions();
  }
}
