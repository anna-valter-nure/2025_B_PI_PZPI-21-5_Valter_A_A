import { CommonModule, NgOptimizedImage } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { TranslatePipe } from '@ngx-translate/core';
import { AnimateOnScroll } from 'primeng/animateonscroll';
import { Button } from 'primeng/button';
import { Chip } from 'primeng/chip';
import { InputGroup } from 'primeng/inputgroup';
import { InputText } from 'primeng/inputtext';
import { Select } from 'primeng/select';
import { Tag } from 'primeng/tag';
import { LandingRoutingModule } from './landing-routing.module';
import { LandingComponent } from './landing.component';

@NgModule({
  declarations: [LandingComponent],
  imports: [
    CommonModule,
    LandingRoutingModule,
    Button,
    NgOptimizedImage,
    Chip,
    AnimateOnScroll,
    InputGroup,
    InputText,
    Tag,
    TranslatePipe,
    Select,
    FormsModule,
  ],
})
export class LandingModule {}
