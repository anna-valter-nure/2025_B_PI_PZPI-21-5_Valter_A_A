import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { Button } from 'primeng/button';
import { Paginator } from 'primeng/paginator';
import { SelectButton } from 'primeng/selectbutton';
import { SidebarModule } from '../../../shared/ui/sidebar/sidebar.module';
import { WishlistCardModule } from '../../ui/wishlist-card/wishlist-card.module';
import { WishlistSkeletonModule } from '../../ui/wishlist-skeleton/wishlist-skeleton.module';
import { PublicWishlistsRoutingModule } from './public-wishlists-routing.module';
import { PublicWishlistsComponent } from './public-wishlists.component';

@NgModule({
  declarations: [PublicWishlistsComponent],
  imports: [
    CommonModule,
    PublicWishlistsRoutingModule,
    SidebarModule,
    WishlistCardModule,
    Button,
    SelectButton,
    WishlistSkeletonModule,
    Paginator,
  ],
})
export class PublicWishlistsModule {}
