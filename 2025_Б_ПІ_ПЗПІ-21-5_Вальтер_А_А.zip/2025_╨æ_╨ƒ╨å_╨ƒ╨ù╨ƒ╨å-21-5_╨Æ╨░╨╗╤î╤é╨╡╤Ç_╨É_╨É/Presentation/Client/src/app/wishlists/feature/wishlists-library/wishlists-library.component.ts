import { Component, OnInit } from '@angular/core';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { WishlistsService } from '../../data-access/wishlists.service';
import { AccessType } from '../../models/accessRights';
import { WishlistBriefResponse } from '../../models/wishlist';
import { CreateDialogComponent } from '../../ui/create-dialog/create-dialog.component';
import {PaginatorState} from "primeng/paginator";

@Component({
  selector: 'app-wishlists-library',
  templateUrl: './wishlists-library.component.html',
  standalone: false,
  providers: [DialogService],
})
export class WishlistsLibraryComponent implements OnInit {
  ref: DynamicDialogRef | undefined;
  selectedFilter: AccessType = AccessType.Owner;
  accessTypeOptions: any[] = [
    { label: 'Owner', value: AccessType.Owner },
    { label: 'Editor', value: AccessType.Editor },
    { label: 'Viewer', value: AccessType.Viewer },
  ];
  wishlists: WishlistBriefResponse[] = [];
  loading = false;
  pageNumber: number = 1;
  pageSize: number = 10;
  totalRecords: number = 0;

  constructor(
    private wishlistsService: WishlistsService,
    private dialogService: DialogService,
  ) {}

  ngOnInit() {
    this.loadWishlists();
  }

  openCreateDialog() {
    this.ref = this.dialogService.open(CreateDialogComponent, {
      modal: true,
      showHeader: false,
      width: '450px',
    });

    this.ref.onClose.subscribe((result) => {
      if (result) {
        this.loadWishlists();
      }
    });
  }

  loadWishlists() {
    this.loading = true;
    this.wishlistsService.get(this.selectedFilter, this.pageNumber, this.pageSize).subscribe({
      next: (response) => {
        this.wishlists = response.collection;
        this.pageNumber = response.pageNumber;
        this.pageSize = response.pageSize;
        this.totalRecords = response.totalPages * response.pageSize;
      },
      complete: () => {
        this.loading = false;
      },
    });
  }

  onWishlistDeleted(wishlistId: string) {
    this.wishlists = this.wishlists.filter(
      (wishlist) => wishlist.id !== wishlistId,
    );
  }

  onWishlistUpdated() {
    this.loadWishlists();
  }

  onPageChange(event: PaginatorState) {
    if (event.first) {
      this.pageNumber = Math.ceil((event.first + 1) / this.pageSize);
    } else {
      this.pageNumber = 1;
    }

    this.loadWishlists();
  }
}
