import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PublicWishlistPageRoutingModule } from './public-wishlist-page-routing.module';
import { PublicWishlistPageComponent } from './public-wishlist-page.component';
import {SidebarModule} from "../../../shared/ui/sidebar/sidebar.module";
import {WishlistCardModule} from "../../ui/wishlist-card/wishlist-card.module";
import {GiftCardModule} from "../../../gifts/ui/gift-card/gift-card.module";
import {DropdownModule} from "../../../shared/ui/dropdown/dropdown.module";
import {Button} from "primeng/button";
import {Tag} from "primeng/tag";
import {
  GiftAddToWishlistDialogModule
} from "../../../gifts/ui/gift-add-to-wishlist-dialog/gift-add-to-wishlist-dialog.module";


@NgModule({
  declarations: [
    PublicWishlistPageComponent
  ],
  imports: [
    CommonModule,
    PublicWishlistPageRoutingModule,
    SidebarModule,
    WishlistCardModule,
    GiftCardModule,
    DropdownModule,
    Button,
    Tag,
    GiftAddToWishlistDialogModule,
  ]
})
export class PublicWishlistPageModule { }
