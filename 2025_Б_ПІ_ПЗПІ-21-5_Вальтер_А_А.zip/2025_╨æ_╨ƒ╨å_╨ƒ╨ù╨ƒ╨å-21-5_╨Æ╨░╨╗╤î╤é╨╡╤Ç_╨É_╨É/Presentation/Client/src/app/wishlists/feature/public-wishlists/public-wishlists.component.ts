import { Component, OnInit } from '@angular/core';
import { DialogService } from 'primeng/dynamicdialog';
import { PaginatorState } from 'primeng/paginator';
import { WishlistsService } from '../../data-access/wishlists.service';
import { WishlistBriefResponse } from '../../models/wishlist';

@Component({
  standalone: false,
  selector: 'app-public-wishlists',
  templateUrl: './public-wishlists.component.html',
  providers: [DialogService],
})
export class PublicWishlistsComponent implements OnInit {
  isLoading: boolean = false;
  wishlists: WishlistBriefResponse[] = [];
  pageNumber: number = 1;
  pageSize: number = 10;
  totalRecords: number = 0;

  constructor(private wishlistsService: WishlistsService) {}

  ngOnInit() {
    this.loadWishlists();
  }

  loadWishlists() {
    this.isLoading = true;
    this.wishlistsService
      .getPublicWishlists(this.pageNumber, this.pageSize)
      .subscribe((response) => {
        this.wishlists = response.collection;
        this.pageNumber = response.pageNumber;
        this.pageSize = response.pageSize;
        this.totalRecords = response.totalPages * response.pageSize;
        this.isLoading = false;
      });
  }

  onPageChange(event: PaginatorState) {
    if (event.first) {
      this.pageNumber = Math.ceil((event.first + 1) / this.pageSize);
    } else {
      this.pageNumber = 1;
    }

    this.loadWishlists();
  }
}
