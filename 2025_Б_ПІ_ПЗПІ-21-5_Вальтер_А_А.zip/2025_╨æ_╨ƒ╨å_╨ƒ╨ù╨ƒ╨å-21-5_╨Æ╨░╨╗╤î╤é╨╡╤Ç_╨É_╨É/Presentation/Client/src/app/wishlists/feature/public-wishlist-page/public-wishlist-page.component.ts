import {Component, OnDestroy, OnInit} from '@angular/core';
import {GiftCategories, GiftResponse, SharedGiftResponse, SharedGiftStatus} from "../../../gifts/models/gift";
import {AccessType} from "../../models/accessRights";
import {Subject, takeUntil} from "rxjs";
import {Location} from "@angular/common";
import {ActivatedRoute, Router} from "@angular/router";
import {WishlistsService} from "../../data-access/wishlists.service";
import {GiftService} from "../../../gifts/data-access/gift.service";
import {ToastrService} from "ngx-toastr";
import {AuthService} from "../../../auth/data-access/auth.service";
import {DropdownOption} from "../../../shared/models/dropdownOption";
import {DialogService, DynamicDialogRef} from "primeng/dynamicdialog";
import {debounceTime} from "rxjs/operators";
import {
  GiftAddToWishlistDialogComponent
} from "../../../gifts/ui/gift-add-to-wishlist-dialog/gift-add-to-wishlist-dialog.component";
import {MatDialog} from "@angular/material/dialog";

@Component({
  selector: 'app-public-wishlist-page',
  standalone: false,
  templateUrl: './public-wishlist-page.component.html',
  providers: [DialogService],
})
export class PublicWishlistPageComponent implements OnInit, OnDestroy {
  private wishlistId!: string;
  gifts: GiftResponse[] = [];
  accessType!: AccessType;
  wishlistName!: string;
  wishlistCategories!: string;
  createdBy!: string;
  occasionDate!: Date;
  currentUserEmail!: string;

  selectedCategory: string | null = null;

  private filterSubject = new Subject<void>();
  private destroy$ = new Subject<void>();

  readonly categories = GiftCategories;

  private addGiftDialogRef: DynamicDialogRef | undefined;

  constructor(
    private location: Location,
    private route: ActivatedRoute,
    private router: Router,
    private wishlistsService: WishlistsService,
    private giftService: GiftService,
    private toastr: ToastrService,
    private authService: AuthService,
    private dialogService: DialogService,
    public matDialogRefg: MatDialog,
  ) {}

  // TODO: separate ngOnInit into smaller methods
  async ngOnInit(): Promise<void> {
    this.route.params.subscribe((params) => {
      this.wishlistId = params['id'];

      this.wishlistsService
        .checkAccess(this.wishlistId)
        .subscribe(async (accessType) => {
          if (!accessType && accessType !== AccessType.Owner) {
            // Redirect to the not found page if the user has no access to the wishlist
            // TODO: create the not found page
            await this.router.navigate(['/']);
            return;
          }

          // TODO: alter the page based on access type
          this.accessType = accessType;

          this.filterSubject
            .pipe(debounceTime(300), takeUntil(this.destroy$))
            .subscribe(() => {
              this.loadGifts();
            });

          this.loadGifts();
        });
    });

    // The current user is guaranteed to be authenticated at this point
    this.currentUserEmail =
      (await this.authService.getCurrentUserEmail()) as string;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadGifts(): void {
    const filters: {
      categoryNames?: string[];
    } = {};

    if (this.selectedCategory) {
      filters.categoryNames = [this.selectedCategory];
    }

    this.wishlistsService
      .getById(
        this.wishlistId,
        Object.keys(filters).length > 0 ? filters : undefined,
      )
      .subscribe((res) => {
        this.wishlistName = res.name;
        this.wishlistCategories = res.categoryNames.join(' • ');
        this.occasionDate = res.occasionDate;
        this.gifts = res.gifts.collection;
        this.createdBy = res.createdBy;

        if (this.accessType === AccessType.Owner) {
          this.createdBy += ' (You)';
        }
      });
  }

  filterByCategory(option: DropdownOption): void {
    this.selectedCategory = option.value !== null ? String(option.value) : null;
    this.filterSubject.next();
  }

  protected readonly AccessType = AccessType;

  openAddGiftToWishlistDialog(gift: GiftResponse) {
    this.addGiftDialogRef = this.dialogService.open(GiftAddToWishlistDialogComponent, {
      modal: true,
      showHeader: false,
      width: '870px',
      data: {
        gift: gift,
      },
    });

    this.addGiftDialogRef.onClose.subscribe((result) => {
      if (result) {
        this.loadGifts();
      }
    });
  }
}
