export const WishlistCategories = [
  'New Year',
  'Birthday',
  'Christmas',
  'Anniversary',
  'Valentine\'s Day',
  'Wedding',
  'Baby Shower',
  'Graduation',
  'Housewarming',
  'Retirement',
  'Easter',
  'Halloween',
  'Thanksgiving',
  'Black Friday',
  'Summer Vacation'
]
