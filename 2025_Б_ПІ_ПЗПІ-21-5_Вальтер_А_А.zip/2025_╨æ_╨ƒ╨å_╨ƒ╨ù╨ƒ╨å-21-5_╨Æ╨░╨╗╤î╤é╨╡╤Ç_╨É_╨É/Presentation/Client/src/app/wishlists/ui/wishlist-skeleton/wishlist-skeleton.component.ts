import { Component } from '@angular/core';

@Component({
  selector: 'app-wishlist-skeleton',
  standalone: false,
  templateUrl: './wishlist-skeleton.component.html',
})
export class WishlistSkeletonComponent {}
