import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FriendsShellRoutingModule } from './friends-shell-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FriendsShellRoutingModule
  ]
})
export class FriendsShellModule { }
