import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { Badge } from 'primeng/badge';
import { SelectButton } from 'primeng/selectbutton';
import { SidebarModule } from '../../../shared/ui/sidebar/sidebar.module';
import { WishlistCardModule } from '../../../wishlists/ui/wishlist-card/wishlist-card.module';
import { FriendCardModule } from '../../ui/friend-card/friend-card.module';
import { RequestCardModule } from '../../ui/request-card/request-card.module';
import { UserCardModule } from '../../ui/user-card/user-card.module';
import { FriendsListRoutingModule } from './friends-list-routing.module';
import { FriendsListComponent } from './friends-list.component';

@NgModule({
  declarations: [FriendsListComponent],
  imports: [
    CommonModule,
    FriendsListRoutingModule,
    SidebarModule,
    WishlistCardModule,
    UserCardModule,
    FriendCardModule,
    SelectButton,
    FormsModule,
    Badge,
    RequestCardModule,
  ],
})
export class FriendsListModule {}
