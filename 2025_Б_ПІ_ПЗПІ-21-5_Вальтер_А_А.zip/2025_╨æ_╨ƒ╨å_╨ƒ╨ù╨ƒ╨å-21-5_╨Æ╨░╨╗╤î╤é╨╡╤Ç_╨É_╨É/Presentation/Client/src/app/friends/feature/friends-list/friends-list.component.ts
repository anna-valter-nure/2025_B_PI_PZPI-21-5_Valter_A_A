import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../auth/data-access/auth.service';
import { FriendsHubService } from '../../data-access/friends-hub.service';
import { FriendsService } from '../../data-access/friends.service';
import { FriendResponse, InvitationStatus } from '../../ui/friends';
import { UserResponse } from '../../ui/users';

@Component({
  selector: 'app-friends-list',
  templateUrl: './friends-list.component.html',
  standalone: false,
})
export class FriendsListComponent implements OnInit {
  selectedTab: string = 'friends';
  tabOptions: any[] = [
    { label: 'My Friends', value: 'friends', icon: 'pi pi-users' },
    { label: 'Discover', value: 'discover', icon: 'pi pi-user-plus' },
    { label: 'Requests', value: 'requests', icon: 'pi pi-clock' },
  ];
  requestCount: number = 0;
  friends: FriendResponse[] = [];
  users: UserResponse[] = [];
  requests: FriendResponse[] = [];

  constructor(
    private friendsService: FriendsService,
    private friendsHubService: FriendsHubService,
    private authService: AuthService,
  ) {}

  ngOnInit(): void {
    this.initTabCollections();
    this.startFriendsHub();
  }

  onSendFriendRequest(friend: UserResponse) {
    this.friendsService.sendFriendshipRequest(friend.email).subscribe({
      next: (friendshipId) => {
        this.users = this.users.filter((user) => user.email !== friend.email);

        const friendship: FriendResponse = {
          ...friend,
          id: friendshipId,
          status: InvitationStatus.Pending,
          isSender: true,
        };
        this.requests.push(friendship);

        this.authService.getCurrentUser().then((user) => {
          this.friendsHubService.sendFriendRequest(
            friend.email,
            friendshipId,
            user.displayName!,
          );
        });
      },
    });
  }

  onCancelFriendRequest(friend: FriendResponse) {
    this.friendsService.delete(friend.id).subscribe({
      next: () => {
        this.requests = this.requests.filter(
          (request) => request.id !== friend.id,
        );
        this.users.push({ ...friend });

        // If current user is not the sender, then the count of incoming requests should be decremented
        if (!friend.isSender) {
          this.requestCount--;
        }

        this.friendsHubService.deleteFriendRequest(friend.email, friend.id);
      },
    });
  }

  onAcceptFriendRequest(friend: FriendResponse) {
    this.friendsService
      .manageFriendshipRequest({
        friendshipId: friend.id,
        status: InvitationStatus.Accepted,
      })
      .subscribe({
        next: () => {
          this.requests = this.requests.filter(
            (request) => request.id !== friend.id,
          );
          this.friends.push(friend);

          // If current user is not the sender, then the count of incoming requests should be decremented
          if (!friend.isSender) {
            this.requestCount--;
          }

          this.friendsHubService.manageFriendRequest(
            friend.email,
            friend.id,
            InvitationStatus.Accepted,
          );
        },
      });
  }

  private initTabCollections() {
    this.friendsService.getFriends().subscribe({
      next: (pagedResponse) => {
        this.friends = pagedResponse.collection.filter(
          (friend) => friend.status === InvitationStatus.Accepted,
        );
        this.requests = pagedResponse.collection.filter(
          (friend) => friend.status !== InvitationStatus.Accepted,
        );
        this.requestCount = this.requests.filter(
          (friend) =>
            friend.status === InvitationStatus.Pending && !friend.isSender,
        ).length;
      },
    });

    this.friendsService.getPubicUsers().subscribe({
      next: (pagedResponse) => {
        this.users = pagedResponse.collection;
      },
    });
  }

  private startFriendsHub() {
    this.friendsHubService.startConnection();

    this.friendsHubService.friendRequestReceived$.subscribe({
      next: (friendship) => {
        this.users = this.users.filter(
          (user) => user.email !== friendship.email,
        );
        this.requests.push(friendship);
        this.requestCount++;
      },
    });

    this.friendsHubService.friendRequestDeleteReceived$.subscribe({
      next: (friendshipId) => {
        // Push the deleted request to the available users list
        this.users.push({
          ...this.requests.find((request) => request.id === friendshipId)!,
        });

        this.requests = this.requests.filter(
          (request) => request.id !== friendshipId,
        );
      },
    });

    this.friendsHubService.friendRequestStatusReceived$.subscribe({
      next: (friendship) => {
        this.friends.push(
          this.requests.find(
            (request) => request.id === friendship.friendshipId,
          )!,
        );

        this.requests = this.requests.filter(
          (request) => request.id !== friendship.friendshipId,
        );
      },
    });
  }
}
