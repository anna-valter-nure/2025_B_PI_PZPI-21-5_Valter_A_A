import { Component, Input } from '@angular/core';
import { FriendResponse } from '../friends';

@Component({
  selector: 'app-friend-card',
  templateUrl: './friend-card.component.html',
  standalone: false,
})
export class FriendCardComponent {
  @Input() user!: FriendResponse;

  getInitials(fullName: string): string {
    const names = fullName.split(' ');
    let initials = '';
    for (let i = 0; i < names.length; i++) {
      initials += names[i].charAt(0).toUpperCase();
    }
    return initials;
  }
}
