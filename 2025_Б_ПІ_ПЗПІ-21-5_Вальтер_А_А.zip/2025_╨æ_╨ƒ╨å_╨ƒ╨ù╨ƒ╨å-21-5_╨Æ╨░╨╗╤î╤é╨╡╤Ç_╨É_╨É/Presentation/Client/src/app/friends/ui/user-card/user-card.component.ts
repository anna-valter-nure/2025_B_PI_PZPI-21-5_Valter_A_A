import { Component, EventEmitter, Input, Output } from '@angular/core';
import { UserResponse } from '../users';

@Component({
  selector: 'app-user-card',
  templateUrl: './user-card.component.html',
  standalone: false,
})
export class UserCardComponent {
  @Input() user!: UserResponse;
  @Output() addFriend = new EventEmitter<UserResponse>();

  constructor() {}

  getInitials(fullName: string): string {
    const names = fullName.split(' ');
    let initials = '';
    for (let i = 0; i < names.length; i++) {
      initials += names[i].charAt(0).toUpperCase();
    }
    return initials;
  }

  onAddFriend(): void {
    this.addFriend.emit(this.user);
  }
}
