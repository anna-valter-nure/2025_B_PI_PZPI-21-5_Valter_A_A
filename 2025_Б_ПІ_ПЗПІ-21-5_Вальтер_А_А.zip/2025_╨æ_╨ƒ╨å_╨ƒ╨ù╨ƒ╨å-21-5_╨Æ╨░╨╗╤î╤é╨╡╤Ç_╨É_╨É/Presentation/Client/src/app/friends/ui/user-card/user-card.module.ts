import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Avatar } from 'primeng/avatar';
import { Button } from 'primeng/button';
import { UserCardComponent } from './user-card.component';

@NgModule({
  declarations: [UserCardComponent],
  exports: [UserCardComponent],
  imports: [CommonModule, Avatar, Button],
})
export class UserCardModule {}
