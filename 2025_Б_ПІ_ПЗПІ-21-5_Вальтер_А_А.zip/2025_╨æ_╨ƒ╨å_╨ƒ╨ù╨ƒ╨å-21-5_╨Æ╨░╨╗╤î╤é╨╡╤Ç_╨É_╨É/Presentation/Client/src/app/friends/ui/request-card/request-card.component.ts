import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FriendResponse } from '../friends';

@Component({
  selector: 'app-request-card',
  standalone: false,
  templateUrl: './request-card.component.html',
})
export class RequestCardComponent {
  @Input() user!: FriendResponse;
  @Output() cancelFriendRequest = new EventEmitter<FriendResponse>();
  @Output() acceptFriendRequest = new EventEmitter<FriendResponse>();

  getInitials(fullName: string): string {
    const names = fullName.split(' ');
    let initials = '';
    for (let i = 0; i < names.length; i++) {
      initials += names[i].charAt(0).toUpperCase();
    }
    return initials;
  }

  onCancelFriendRequest() {
    this.cancelFriendRequest.emit(this.user);
  }

  onAcceptFriendRequest() {
    this.acceptFriendRequest.emit(this.user);
  }
}
