export interface UserResponse {
  name: string;
  email: string;
}
