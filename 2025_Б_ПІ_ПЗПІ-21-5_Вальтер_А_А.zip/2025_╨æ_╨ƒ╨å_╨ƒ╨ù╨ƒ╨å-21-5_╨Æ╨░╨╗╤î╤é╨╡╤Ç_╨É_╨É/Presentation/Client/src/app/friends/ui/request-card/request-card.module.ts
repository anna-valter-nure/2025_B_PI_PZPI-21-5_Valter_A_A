import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Avatar } from 'primeng/avatar';
import { Button } from 'primeng/button';
import { Tag } from 'primeng/tag';
import { RequestCardComponent } from './request-card.component';

@NgModule({
  declarations: [RequestCardComponent],
  imports: [CommonModule, Avatar, Button, Tag],
  exports: [RequestCardComponent],
})
export class RequestCardModule {}
