import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { Avatar } from 'primeng/avatar';
import { Button } from 'primeng/button';
import { FriendCardComponent } from './friend-card.component';

@NgModule({
  declarations: [FriendCardComponent],
  exports: [FriendCardComponent],
  imports: [CommonModule, Avatar, Button],
})
export class FriendCardModule {}
