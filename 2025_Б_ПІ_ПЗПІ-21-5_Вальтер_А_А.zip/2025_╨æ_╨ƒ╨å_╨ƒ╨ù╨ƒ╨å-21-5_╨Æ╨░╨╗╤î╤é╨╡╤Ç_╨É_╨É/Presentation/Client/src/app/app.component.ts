import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.sass',
  standalone: false,
})
export class AppComponent implements OnInit {
  title = 'Höffly';

  constructor(private translate: TranslateService) {}

  ngOnInit(): void {
    const browserLang = this.translate.getBrowserLang();
    const language = localStorage.getItem('language') || browserLang || 'en';

    this.translate.addLangs(['en', 'uk']);
    this.translate.use(language);
  }
}
