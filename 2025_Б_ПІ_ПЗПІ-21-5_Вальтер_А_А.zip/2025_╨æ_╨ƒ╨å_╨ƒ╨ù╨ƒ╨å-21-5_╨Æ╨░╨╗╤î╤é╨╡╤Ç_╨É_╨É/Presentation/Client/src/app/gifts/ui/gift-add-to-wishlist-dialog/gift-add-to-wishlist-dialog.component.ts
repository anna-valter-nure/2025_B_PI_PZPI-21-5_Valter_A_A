import { Component } from '@angular/core';

@Component({
  selector: 'app-gift-add-to-wishlist-dialog',
  standalone: false,
  templateUrl: './gift-add-to-wishlist-dialog.component.html'
})
export class GiftAddToWishlistDialogComponent {

}
