import { Component, OnInit } from '@angular/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { Subject } from 'rxjs';
import { AccessType } from '../../../wishlists/models/accessRights';
import {
  Currency,
  GiftResponse,
  ReserveAction,
  SharedGiftResponse,
  SharedGiftStatus,
} from '../../models/gift';

@Component({
  selector: 'app-gift-reserve-dialog',
  standalone: false,
  templateUrl: './gift-reserve-dialog.component.html',
})
export class GiftReserveDialogComponent implements OnInit {
  gift: GiftResponse;
  currentUserEmail!: string;
  primaryReserver!: SharedGiftResponse;
  reservedByCurrentUser: boolean = false;
  reservationRequestPending: boolean = false;
  reservationRequestAccepted: boolean = false;
  reservationsCount: number = 0;

  selectedTab: string = 'Reservation Info';
  tabOptions: any[] = [
    { label: 'Reservation Info', value: 'Reservation Info' },
    { label: 'People', value: 'People' },
  ];

  private reserveAction: Subject<{
    action: ReserveAction;
    userEmail?: string;
  }> = new Subject();
  actions$ = this.reserveAction.asObservable();

  constructor(
    config: DynamicDialogConfig,
    private dialogRef: DynamicDialogRef,
  ) {
    this.gift = config.data.gift;
    this.currentUserEmail = config.data.currentUserEmail;
  }

  ngOnInit(): void {
    this.setReservationInfo();
  }

  closeModal(result: boolean = false): void {
    this.dialogRef.close(result);
  }

  getCurrencyString(currency: Currency): string {
    return Currency[currency];
  }

  getReservationText(): string {
    if (this.reservedByCurrentUser || this.reservationRequestAccepted) {
      return 'Reserved by You';
    }

    if (this.reservationRequestPending) {
      return 'Request Pending';
    }

    return 'Reserved';
  }

  getReservationClassName(): string {
    if (this.reservedByCurrentUser || this.reservationRequestAccepted) {
      return 'bg-green-600!';
    }

    if (this.reservationRequestPending) {
      return 'bg-amber-600!';
    }

    return 'bg-red-600!';
  }

  onCancelReservation() {
    this.reserveAction.next({ action: ReserveAction.CancelReservation });
    this.closeModal();
  }

  onJoinReservation() {
    this.reserveAction.next({ action: ReserveAction.RequestSharedReservation });
  }

  onAcceptReservation(userEmail: string) {
    this.reserveAction.next({
      action: ReserveAction.AcceptSharedReservation,
      userEmail: userEmail,
    });
  }

  getInitials(fullName: string): string {
    const names = fullName.split(' ');
    let initials = '';
    for (let i = 0; i < names.length; i++) {
      initials += names[i].charAt(0).toUpperCase();
    }
    return initials;
  }

  get coReservers() {
    return this.gift.sharedGifts.filter(
      (g) => g.userEmail !== this.primaryReserver.userEmail,
    );
  }

  private setReservationInfo(): void {
    this.primaryReserver = this.gift.sharedGifts.find((sharedGift) => {
      return sharedGift.status === SharedGiftStatus.Primary;
    })!;

    this.reservedByCurrentUser =
      this.primaryReserver.userEmail === this.currentUserEmail;

    this.reservationRequestPending = this.gift.sharedGifts.some(
      (sharedGift) =>
        sharedGift.userEmail === this.currentUserEmail &&
        sharedGift.status === SharedGiftStatus.Pending,
    );

    this.reservationRequestAccepted = this.gift.sharedGifts.some(
      (sharedGift) =>
        sharedGift.userEmail === this.currentUserEmail &&
        sharedGift.status === SharedGiftStatus.Accepted,
    );

    this.reservationsCount = this.gift.sharedGifts.filter(
      (sharedGift) => sharedGift.status !== SharedGiftStatus.Pending,
    ).length;
  }

  protected readonly AccessType = AccessType;
  protected readonly ReservationStatus = SharedGiftStatus;
}
