import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GiftAddToWishlistDialogComponent } from './gift-add-to-wishlist-dialog.component';
import {Button} from "primeng/button";
import {InputText} from "primeng/inputtext";
import {Select} from "primeng/select";
import {ReactiveFormsModule} from "@angular/forms";
import {Textarea} from "primeng/textarea";
import {InputNumber} from "primeng/inputnumber";
import {InputGroup} from "primeng/inputgroup";
import {Tooltip} from "primeng/tooltip";
import {Toast} from "primeng/toast";



@NgModule({
  declarations: [ GiftAddToWishlistDialogComponent ],
  imports: [
    CommonModule,
    Button,
    InputText,
    Select,
    ReactiveFormsModule,
    Textarea,
    InputNumber,
    InputGroup,
    Tooltip,
    Toast,
  ]
})
export class GiftAddToWishlistDialogModule { }
