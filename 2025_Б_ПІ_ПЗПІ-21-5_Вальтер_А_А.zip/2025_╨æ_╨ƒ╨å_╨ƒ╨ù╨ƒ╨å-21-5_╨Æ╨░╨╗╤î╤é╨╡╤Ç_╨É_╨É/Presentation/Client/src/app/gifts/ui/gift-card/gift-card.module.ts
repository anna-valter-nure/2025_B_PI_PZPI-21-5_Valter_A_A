import { CommonModule, NgOptimizedImage } from '@angular/common';
import { NgModule } from '@angular/core';
import { Button, ButtonDirective } from 'primeng/button';
import { Menu } from 'primeng/menu';
import { Tag } from 'primeng/tag';
import { GiftCardComponent } from './gift-card.component';

@NgModule({
  declarations: [GiftCardComponent],
  exports: [GiftCardComponent],
  imports: [CommonModule, Tag, Button, Menu, ButtonDirective, NgOptimizedImage],
})
export class GiftCardModule {}
