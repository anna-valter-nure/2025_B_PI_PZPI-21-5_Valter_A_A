import { CommonModule, NgOptimizedImage } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Avatar } from 'primeng/avatar';
import { Button } from 'primeng/button';
import { SelectButton } from 'primeng/selectbutton';
import { Tag } from 'primeng/tag';
import { GiftReserveDialogComponent } from './gift-reserve-dialog.component';

@NgModule({
  declarations: [GiftReserveDialogComponent],
  imports: [
    CommonModule,
    Button,
    NgOptimizedImage,
    Tag,
    SelectButton,
    FormsModule,
    Avatar,
  ],
})
export class GiftReserveDialogModule {}
