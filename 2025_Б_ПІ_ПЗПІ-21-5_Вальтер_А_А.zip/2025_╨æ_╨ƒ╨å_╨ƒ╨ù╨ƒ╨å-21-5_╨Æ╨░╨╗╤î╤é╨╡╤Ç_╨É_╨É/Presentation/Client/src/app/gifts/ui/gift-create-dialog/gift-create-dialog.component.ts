import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { MessageService } from 'primeng/api';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ImageService } from '../../../shared/data-access/image.service';
import { GiftService } from '../../data-access/gift.service';
import {
  Currency,
  CurrencyCategories,
  GiftCategories,
  GiftCreateRequest,
  GiftResponse,
  GiftUpdateRequest,
  PriorityCategories,
} from '../../models/gift';

@Component({
  selector: 'app-gift-create-dialog',
  standalone: false,
  templateUrl: './gift-create-dialog.component.html',
  providers: [MessageService],
})
export class GiftCreateDialogComponent implements OnInit {
  private readonly wishlistId: string;
  private readonly gift: GiftResponse | undefined;
  isEditMode: boolean = false;
  giftCreateForm!: FormGroup;

  categoryDropdownOptions = GiftCategories;
  currencyDropdownOptions = CurrencyCategories;
  priorityDropdownOptions = PriorityCategories;

  private imageFile: File | null = null;
  previewImage: SafeUrl | string | null = null;
  imagePreviewLoading = false;

  isProcessingGift = false;
  isScraping = false;

  constructor(
    private config: DynamicDialogConfig,
    private dialogRef: DynamicDialogRef,
    private fb: FormBuilder,
    private sanitizer: DomSanitizer,
    private imageService: ImageService,
    private giftService: GiftService,
    private messageService: MessageService,
  ) {
    this.wishlistId = this.config.data.wishlistId;
    this.gift = this.config.data.gift;
    this.isEditMode = this.gift !== undefined;
  }

  ngOnInit() {
    this.initForm();
  }

  closeDialog(result: boolean = false): void {
    this.dialogRef.close(result);
  }

  loadImageFromUrl(url: string): void {
    this.imagePreviewLoading = true;

    // Create an image element to test if the URL loads properly
    const img = new Image();
    img.onload = () => {
      this.previewImage = this.sanitizer.bypassSecurityTrustUrl(url);
      this.imagePreviewLoading = false;
    };

    img.onerror = () => {
      this.previewImage = null;
      this.imagePreviewLoading = false;
    };

    img.src = url;
    if (!this.isEditMode) {
      this.giftCreateForm.get('photoLink')?.setValue(url, { emitEvent: false });
    }
  }

  uploadImage(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.imageFile = file;

      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.previewImage = this.sanitizer.bypassSecurityTrustUrl(
          e.target.result,
        );

        // Clear the URL input as we're now using an uploaded file
        this.giftCreateForm
          .get('photoLink')
          ?.setValue('', { emitEvent: false });
      };
      reader.readAsDataURL(file);
    }
  }

  onImageUpload(): void {
    // If there's a URL in the input, load that image
    const url = this.giftCreateForm.get('photoLink')?.value;

    if (url && url.trim()) {
      this.loadImageFromUrl(url);
    } else {
      document.getElementById('fileUpload')?.click();
    }
  }

  onShopDataSync(): void {
    this.isScraping = true;
    this.giftService.scrapeGiftDetails(this.shopLink!).subscribe((res) => {
      this.isScraping = false;

      if (res.isEmpty) {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'No data found for the provided link',
        });
        return;
      }

      if (res.name) {
        this.giftCreateForm.patchValue({
          name: res.name,
        });
      }

      if (res.price) {
        this.giftCreateForm.patchValue({
          price: res.price,
        });
      }

      if (res.currency) {
        this.giftCreateForm.patchValue({
          currency: this.currencyDropdownOptions.find(
            (currency) => currency.definition === res.currency,
          )?.value,
        });
      }

      if (res.imageUrl) {
        this.loadImageFromUrl(res.imageUrl);
      }
    });
  }

  onSubmit(): void {
    if (this.giftCreateForm.invalid) {
      return;
    }

    this.isProcessingGift = true;

    if (this.isEditMode) {
      let giftUpdateRequest: GiftUpdateRequest = {
        ...this.giftCreateForm.value,
        id: this.gift?.id,
        photoLink: this.gift?.photoLink,
        thumbnailLink: this.gift?.thumbnailLink,
      };

      if (this.imageFile) {
        this.updateGiftWithImageUpload(this.imageFile, giftUpdateRequest);
        return;
      }

      if (this.photoLink) {
        this.updateGiftWithImageUpload(this.photoLink, giftUpdateRequest);
        return;
      }

      this.giftService.update(giftUpdateRequest).subscribe(() => {
        this.closeDialog(true);
        return;
      });
    } else {
      let giftCreateRequest: GiftCreateRequest = {
        ...this.giftCreateForm.value,
      };

      if (this.imageFile) {
        this.createGiftWithImageUpload(this.imageFile, giftCreateRequest);
        return;
      }

      if (this.photoLink) {
        this.createGiftWithImageUpload(this.photoLink, giftCreateRequest);
        return;
      }

      this.giftService.create(giftCreateRequest).subscribe(() => {
        this.closeDialog(true);
        return;
      });
    }
  }

  get currency(): string {
    return Currency[this.giftCreateForm.get('currency')?.value];
  }

  get shopLink(): string | undefined {
    return this.giftCreateForm.get('shopLink')?.value;
  }

  get photoLink(): string | undefined {
    return this.giftCreateForm.get('photoLink')?.value;
  }

  private initForm(): void {
    this.giftCreateForm = this.fb.group({
      name: [this.gift?.name || '', Validators.required],
      categoryName: [
        this.gift?.categoryName || 'Electronics',
        Validators.required,
      ],
      note: [this.gift?.note || ''],
      shopLink: [this.gift?.shopLink || ''],
      photoLink: [''],
      thumbnailLink: [this.gift?.thumbnailLink || ''],
      price: [this.gift?.price || 0, Validators.required],
      currency: [this.gift?.currency || Currency.USD, Validators.required],
      priority: [this.gift?.priority || 0, Validators.required],
      wishlistId: [this.wishlistId],
    });

    if (this.gift) {
      this.loadImageFromUrl(this.gift.photoLink);
    }

    this.giftCreateForm.get('photoLink')?.valueChanges.subscribe((link) => {
      if (link && link.trim()) {
        this.loadImageFromUrl(link);
      } else {
        this.previewImage = null;
      }
    });
  }

  private createGiftWithImageUpload(
    image: File | string,
    giftCreateRequest: GiftCreateRequest,
  ): void {
    this.imageService
      .uploadImage(image, this.giftCreateForm.value.name)
      .subscribe({
        next: (imageBbResponse) => {
          giftCreateRequest.photoLink = imageBbResponse.data.image.url;
          giftCreateRequest.thumbnailLink = imageBbResponse.data.thumb.url;

          this.giftService.create(giftCreateRequest).subscribe(() => {
            this.closeDialog(true);
            return;
          });
        },
        error: () => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail:
              'Cannot download remote image. Please upload an image instead',
          });

          this.previewImage = null;
          this.imageFile = null;
          this.giftCreateForm
            .get('photoLink')
            ?.setValue('', { emitEvent: false });
          this.isProcessingGift = false;
        },
      });
  }

  private updateGiftWithImageUpload(
    image: File | string,
    giftUpdateRequest: GiftUpdateRequest,
  ): void {
    this.imageService
      .uploadImage(image, this.giftCreateForm.value.name)
      .subscribe({
        next: (imageBbResponse) => {
          giftUpdateRequest.photoLink = imageBbResponse.data.image.url;
          giftUpdateRequest.thumbnailLink = imageBbResponse.data.thumb.url;

          this.giftService.update(giftUpdateRequest).subscribe(() => {
            this.closeDialog(true);
            return;
          });
        },
        error: () => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail:
              'Cannot download remote image. Please upload an image instead',
          });

          this.previewImage = null;
          this.imageFile = null;
          this.giftCreateForm
            .get('photoLink')
            ?.setValue('', { emitEvent: false });
          this.isProcessingGift = false;
        },
      });
  }
}
