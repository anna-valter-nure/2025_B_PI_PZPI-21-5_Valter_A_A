export const environment = {
  isProduction: true
};
