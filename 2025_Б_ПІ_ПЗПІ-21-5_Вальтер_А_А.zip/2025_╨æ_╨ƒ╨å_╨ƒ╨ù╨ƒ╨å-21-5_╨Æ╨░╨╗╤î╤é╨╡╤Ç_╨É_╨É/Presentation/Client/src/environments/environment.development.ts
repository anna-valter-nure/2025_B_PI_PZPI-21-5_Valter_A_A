export const environment = {
  isProduction: false,
  apiUrl: 'https://localhost:8080/api',
  firebase: {
    apiKey: "AIzaSyCE4jOccC5wEW9QJcOtpGRH9v3aSWoZXgQ",
    authDomain: "hoeffly-33fbb.firebaseapp.com",
    projectId: "hoeffly-33fbb",
    storageBucket: "hoeffly-33fbb.appspot.com",
    messagingSenderId: "973827191558",
    appId: "1:973827191558:web:721088f5ce83747aec2487"
  }
};
