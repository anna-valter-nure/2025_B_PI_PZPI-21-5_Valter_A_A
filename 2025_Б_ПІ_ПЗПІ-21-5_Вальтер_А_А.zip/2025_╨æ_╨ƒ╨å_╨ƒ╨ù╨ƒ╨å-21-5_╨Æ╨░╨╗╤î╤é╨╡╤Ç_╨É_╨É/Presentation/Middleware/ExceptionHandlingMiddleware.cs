﻿using System.Net;
using System.Text.Json;
using Domain.Common;
using Infrastructure.Resources.Exceptions;
using Microsoft.Extensions.Localization;

namespace Presentation.Middleware;

public class ExceptionHandlingMiddleware(
    RequestDelegate next,
    ILogger<ExceptionHandlingMiddleware> logger,
    IStringLocalizer<ExceptionsMessages> localizer)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (Exception ex)
        {
            await HandleExceptionAsync(context, ex);
        }
    }

    private async Task HandleExceptionAsync(HttpContext context, Exception ex)
    {
        logger.LogError(ex, ex.Message);

        var httpStatusCode = ex is ExceptionBase exceptionBase
            ? exceptionBase.HttpStatusCode
            : HttpStatusCode.InternalServerError;

        var messageKey = ex.Message;
        var localizedMessage = localizer[messageKey];

        var problem = new ProblemDetails
        {
            Status = (int)httpStatusCode,
            Type = httpStatusCode.ToString(),
            Detail = localizedMessage,
        };

        var problemJson = JsonSerializer.Serialize(problem);
        context.Response.StatusCode = (int)httpStatusCode;
        context.Response.ContentType = "application/json";
        await context.Response.WriteAsync(problemJson);
    }
}
