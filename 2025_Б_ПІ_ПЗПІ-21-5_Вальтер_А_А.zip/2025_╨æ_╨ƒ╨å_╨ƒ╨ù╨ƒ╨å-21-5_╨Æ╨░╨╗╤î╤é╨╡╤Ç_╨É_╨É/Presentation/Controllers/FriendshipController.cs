using Application.Common.Models;
using Application.Users.Commands.DeleateFriend;
using Application.Users.Commands.ManageFriendRequest;
using Application.Users.Commands.SendFriendRequest;
using Application.Users.Queries.GetFriends;
using Application.Users.Queries.GetUsers;
using Domain.Enums;
using MediatR;
using Swashbuckle.AspNetCore.Annotations;

namespace Presentation.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class FriendshipController(IMediator mediatr) : ControllerBase
{
    [SwaggerResponse(StatusCodes.Status204NoContent)]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [SwaggerResponse(StatusCodes.Status404NotFound)]
    [HttpPost("send")]
    public async Task<IActionResult> SendFriendRequest([FromBody] SendFriendRequestCommand command, CancellationToken cancellationToken)
    {
        await mediatr.Send(command, cancellationToken);
        return NoContent();
    }

    [SwaggerResponse(StatusCodes.Status200OK, Type = typeof(InvitationStatus))]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [SwaggerResponse(StatusCodes.Status404NotFound)]
    [HttpPut("manage")]
    public async Task<IActionResult> ManageFriendRequest([FromBody] ManageFriendRequestCommand command, CancellationToken cancellationToken)
    {
        var result = await mediatr.Send(command, cancellationToken);
        return Ok(result);
    }

    [SwaggerResponse(StatusCodes.Status204NoContent)]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [SwaggerResponse(StatusCodes.Status404NotFound)]
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteFriend(Guid id, CancellationToken cancellationToken)
    {
        await mediatr.Send(new DeleteFriendCommand(id), cancellationToken);
        return NoContent();
    }

    [SwaggerResponse(StatusCodes.Status200OK, Type = typeof(PageResponse<FriendsResponse>))]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [HttpGet]
    public async Task<IActionResult> GetFriends([FromQuery] GetFriendsQuery query, CancellationToken cancellationToken)
    {
        var result = await mediatr.Send(query, cancellationToken);
        return Ok(result);
    }

    [SwaggerResponse(StatusCodes.Status200OK, Type = typeof(PageResponse<UsersResponse>))]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [HttpGet("users")]
    public async Task<IActionResult> GetPublicUsers([FromQuery] GetUsersQuery query, CancellationToken cancellationToken)
    {
        var result = await mediatr.Send(query, cancellationToken);
        return Ok(result);
    }
}
