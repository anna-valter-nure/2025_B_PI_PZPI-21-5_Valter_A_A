using Application.Profile.Commands.ChangeProfileVisibility;
using Application.Profile.Commands.UpdateProfile;
using Application.Profile.Queries.GetProfile;
using MediatR;
using Swashbuckle.AspNetCore.Annotations;

namespace Presentation.Controllers.Profile;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class ProfileController(IMediator mediatr) : ControllerBase
{
    [SwaggerResponse(
        StatusCodes.Status200OK,
        Type = typeof(Application.Profile.Queries.GetProfile.Profile))]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status404NotFound)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [HttpGet("{email}")]
    public async Task<IActionResult> GetProfileAsync(string email, CancellationToken cancellationToken)
    {
        var profile = await mediatr.Send(new GetProfileQuery(email), cancellationToken);
        return Ok(profile);
    }

    [SwaggerResponse(StatusCodes.Status204NoContent)]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status400BadRequest)]
    [SwaggerResponse(StatusCodes.Status404NotFound)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [HttpPut]
    public async Task<IActionResult> UpdateProfileAsync([FromBody] UpdateProfileCommand command, CancellationToken cancellationToken)
    {
        await mediatr.Send(command, cancellationToken);
        return NoContent();
    }

    [SwaggerResponse(StatusCodes.Status204NoContent)]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status404NotFound)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [HttpPut("visibility")]
    public async Task<IActionResult> ChangeProfileVisibilityAsync(CancellationToken cancellationToken)
    {
        await mediatr.Send(new ChangeProfileVisibilityCommand(), cancellationToken);
        return NoContent();
    }
}
