using Application.Common.Models;
using Application.Profile.Commands.CreateOccasion;
using Application.Profile.Commands.DeleteOccasion;
using Application.Profile.Commands.UpdateOccasion;
using Application.Profile.Queries.GetOccasionById;
using Application.Profile.Queries.GetOccasionsByEmail;
using MediatR;
using Swashbuckle.AspNetCore.Annotations;

namespace Presentation.Controllers.Profile;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class OccasionController(IMediator mediatr) : ControllerBase
{
    [SwaggerResponse(StatusCodes.Status201Created)]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status400BadRequest)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [HttpPost]
    public async Task<IActionResult> Create(
        [FromBody] CreateOccasionCommand command,
        CancellationToken cancellationToken)
    {
        await mediatr.Send(command, cancellationToken);
        return Created();
    }

    [SwaggerResponse(StatusCodes.Status204NoContent)]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status404NotFound)]
    [SwaggerResponse(StatusCodes.Status403Forbidden)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete([FromRoute] Guid id, CancellationToken cancellationToken)
    {
        await mediatr.Send(new DeleteOccasionCommand(id), cancellationToken);
        return NoContent();
    }

    [SwaggerResponse(StatusCodes.Status204NoContent)]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status400BadRequest)]
    [SwaggerResponse(StatusCodes.Status404NotFound)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [HttpPut]
    public async Task<IActionResult> Update([FromBody] UpdateOccasionCommand command, CancellationToken cancellationToken)
    {
        await mediatr.Send(command, cancellationToken);
        return NoContent();
    }

    [SwaggerResponse(StatusCodes.Status200OK, Type = typeof(PageResponse<OccasionResponse>))]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status404NotFound)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [HttpGet]
    public async Task<IActionResult> GetOccasionsByEmail([FromQuery] GetOccasionsByEmailQuery query, CancellationToken cancellationToken)
    {
        var occasions = await mediatr.Send(query, cancellationToken);
        return Ok(occasions);
    }

    [SwaggerResponse(StatusCodes.Status200OK, Type = typeof(IEnumerable<OccasionResponse>))]
    [SwaggerResponse(StatusCodes.Status403Forbidden)]
    [SwaggerResponse(StatusCodes.Status401Unauthorized)]
    [SwaggerResponse(StatusCodes.Status404NotFound)]
    [SwaggerResponse(StatusCodes.Status500InternalServerError)]
    [HttpGet("{id}")]
    public async Task<IActionResult> GetOccasionById(Guid id, CancellationToken cancellationToken)
    {
        var occasion = await mediatr.Send(new GetOccasionByIdQuery(id), cancellationToken);
        return Ok(occasion);
    }
}
