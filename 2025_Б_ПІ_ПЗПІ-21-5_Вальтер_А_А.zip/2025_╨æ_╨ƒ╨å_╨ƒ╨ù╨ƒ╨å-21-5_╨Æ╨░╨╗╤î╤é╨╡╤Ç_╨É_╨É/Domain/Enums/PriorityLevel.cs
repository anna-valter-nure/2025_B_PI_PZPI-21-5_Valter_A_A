﻿namespace Domain.Enums;

public enum PriorityLevel
{
    MustHave,
    ReallyWanted,
    WouldLike,
    NiceToHave,
    Optional,
}