﻿namespace Domain.Enums;

public enum Currency
{
    Euro,
    UkrainianHryvnia,
    UnitedStatesDollar,
}