namespace Domain.Enums;

public enum SharedGiftStatus
{
    Pending,
    Accepted,
    Primary,
}
