﻿namespace Domain.Enums;

public enum InvitationStatus
{
    Pending,
    Accepted,
    Rejected,
}