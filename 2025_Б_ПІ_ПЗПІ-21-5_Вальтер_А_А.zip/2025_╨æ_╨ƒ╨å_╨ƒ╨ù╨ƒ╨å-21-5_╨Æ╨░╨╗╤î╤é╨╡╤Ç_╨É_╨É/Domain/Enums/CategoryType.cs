namespace Domain.Enums;

public enum CategoryType
{
    Wishlist,
    Gift,
}