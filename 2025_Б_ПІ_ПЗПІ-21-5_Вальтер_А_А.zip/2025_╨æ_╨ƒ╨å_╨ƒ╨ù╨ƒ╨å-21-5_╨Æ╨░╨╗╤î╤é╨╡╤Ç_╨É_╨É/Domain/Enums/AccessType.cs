﻿namespace Domain.Enums;

public enum AccessType
{
    Owner = 0,
    Editor = 1,
    Viewer = 2,
}
