﻿namespace Domain.Enums;

public enum TeamRole
{
    Creator,
    Member,
}