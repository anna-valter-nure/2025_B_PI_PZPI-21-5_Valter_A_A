﻿namespace Domain.Enums;

public enum Gender
{
    NotSpecified,
    Male,
    Female,
    NonBinary,
}