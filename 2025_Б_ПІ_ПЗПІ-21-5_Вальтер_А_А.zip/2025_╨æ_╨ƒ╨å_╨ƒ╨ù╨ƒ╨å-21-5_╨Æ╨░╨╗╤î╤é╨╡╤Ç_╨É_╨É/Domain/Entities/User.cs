﻿using Domain.Enums;

namespace Domain.Entities;

public class User : EntityBase
{
    public required string Name { get; set; }

    public required string Email { get; set; }

    public required string FirebaseUid { get; set; }

    public string? Bio { get; set; }

    public string? AvatarUrl { get; set; }

    public Gender Gender { get; set; } = Gender.NotSpecified;

    public DateTime? DateOfBirth { get; set; }

    public string? ClothingSize { get; set; }

    public string? ShoeSize { get; set; }

    public string? RingSize { get; set; }

    public string? FavoriteColor { get; set; }

    public string? Hobby { get; set; }

    public bool IsPublic { get; set; }

    public bool AllowFriendRequests { get; set; }

    public bool ShowBirthday { get; set; }

    public ICollection<Occasion> Occasions { get; } = new List<Occasion>();

    public ICollection<Friendship> Friendships { get; } = new List<Friendship>();

    public ICollection<SharedGift> SharedGifts { get; } = new List<SharedGift>();

    public ICollection<AccessRights> AccessRights { get; } = new List<AccessRights>();

    public ICollection<TeamUser> TeamUsers { get; } = new List<TeamUser>();

    public ICollection<Message> Messages { get; } = new List<Message>();
}