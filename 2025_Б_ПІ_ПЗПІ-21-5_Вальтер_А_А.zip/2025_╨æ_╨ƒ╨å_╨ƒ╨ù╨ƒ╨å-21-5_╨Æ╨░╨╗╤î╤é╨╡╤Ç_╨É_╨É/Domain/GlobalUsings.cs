﻿// Global using directives

global using System.Net;
global using Domain.Common;