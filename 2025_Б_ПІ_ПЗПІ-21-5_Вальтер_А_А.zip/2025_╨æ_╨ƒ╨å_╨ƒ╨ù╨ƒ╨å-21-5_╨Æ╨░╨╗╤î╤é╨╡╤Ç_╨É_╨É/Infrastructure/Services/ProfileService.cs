using System.Security.Claims;
using Domain.Exceptions;
using Microsoft.AspNetCore.Http;

namespace Infrastructure.Services;

public class ProfileService(
    IRepository<User> userRepository,
    IUnitOfWork unitOfWork,
    IHttpContextAccessor httpContextAccessor)
    : IProfileService
{
    public async Task<User> GetProfileAsync(string email, CancellationToken cancellationToken)
    {
        var isCurrentUser = email == GetUserEmailFromContext();
        var user = await userRepository.GetQueryable()
                              .AsNoTracking()
                              .FirstOrDefaultAsync(u => u.Email == email && (u.IsPublic || isCurrentUser), cancellationToken)
                          ?? throw new NotFoundException("UserNotFound");

        return user;
    }

    public async Task ChangeProfileVisibilityAsync(CancellationToken cancellationToken)
    {
        var userEmail = GetUserEmailFromContext();

        var user = await userRepository.GetQueryable()
                              .AsNoTracking()
                              .FirstOrDefaultAsync(u => u.Email == userEmail, cancellationToken) 
                   ?? throw new NotFoundException("UserNotFound");

        user.IsPublic = !user.IsPublic;

        userRepository.Update(user);
        await unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task UpdateProfileAsync(User user, CancellationToken cancellationToken)
    {
        var currentUserEmail = GetUserEmailFromContext();
        var userToUpdate = await userRepository.GetQueryable()
                                      .FirstOrDefaultAsync(u => u.Email == currentUserEmail, cancellationToken)
                           ?? throw new NotFoundException("UserNotFound");

        userToUpdate.Name = user.Name;
        userToUpdate.Bio = user.Bio;
        userToUpdate.AvatarUrl = user.AvatarUrl;
        userToUpdate.Hobby = user.Hobby;
        userToUpdate.Gender = user.Gender;
        userToUpdate.DateOfBirth = user.DateOfBirth;

        userRepository.Update(userToUpdate);
        await unitOfWork.SaveChangesAsync(cancellationToken);
    }

    private string GetUserEmailFromContext() => httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value!;
}
