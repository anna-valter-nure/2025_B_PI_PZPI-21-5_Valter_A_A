using System.Security.Claims;
using Domain.Enums;
using Domain.Exceptions;
using Microsoft.AspNetCore.Http;

namespace Infrastructure.Services;

public class FriendshipService(
    IRepository<Friendship> friendshipRepository,
    IRepository<User> userRepository,
    IUnitOfWork unitOfWork,
    IHttpContextAccessor httpContextAccessor)
    : IFriendshipService
{
    public async Task<Guid> SendFriendRequestAsync(string recipientEmail, CancellationToken cancellationToken)
    {
        var requester = await GetUserByEmailAsync(GetUserEmailFromContext(), cancellationToken);
        var recipient = await GetUserByEmailAsync(recipientEmail, cancellationToken);

        if (requester == null)
        {
            throw new NotFoundException("RequesterNotFound");
        }

        if (recipient == null)
        {
            throw new NotFoundException("RecipientNotFound");
        }

        if (requester.Id == recipient.Id)
        {
            throw new ConflictException("CannotAddYourselfAsFriend");
        }

        var existingFriendship = await GetExistingFriendshipAsync(requester.Id, recipient.Id, cancellationToken);
        if (existingFriendship != null)
        {
            throw new ConflictException("FriendRequestAlreadyExists");
        }

        var friendship = new Friendship
        {
            RecipientId = recipient.Id,
            RequesterId = requester.Id,
            Status = InvitationStatus.Pending,
            CreatedBy = requester.Email,
            LastModifiedBy = requester.Email,
        };

        await friendshipRepository.AddAsync(friendship, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);

        return friendship.Id;
    }

    public async Task<InvitationStatus> ManageFriendRequestAsync(InvitationStatus status, Guid friendshipId, CancellationToken cancellationToken)
    {
        var friendship = await GetExistingFriendshipAsync(friendshipId, cancellationToken);
        if (friendship == null)
        {
            throw new NotFoundException("FriendshipNotFound");
        }

        if (friendship.Status != InvitationStatus.Pending)
        {
            throw new ConflictException("FriendRequestAlreadyProcessed");
        }

        var userEmail = GetUserEmailFromContext();
        if (friendship.Recipient.Email != userEmail)
        {
            throw new ForbiddenException("OnlyRecipientCanManageFriendRequest");
        }

        friendship.Status = status;

        friendshipRepository.Update(friendship);
        await unitOfWork.SaveChangesAsync(cancellationToken);

        return friendship.Status;
    }

    public async Task DeleteFriendshipAsync(Guid id, CancellationToken cancellationToken)
    {
        var friendship = await GetExistingFriendshipAsync(id, cancellationToken)
                         ?? throw new NotFoundException("FriendshipNotFound");

        var email = GetUserEmailFromContext();
        if (friendship.Recipient.Email != email && friendship.Requester.Email != email)
        {
            throw new ForbiddenException("CanOnlyDeleteOwnFriendships");
        }

        friendshipRepository.Delete(friendship);
        await unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task<(IEnumerable<Friendship> friends, int totalPages, string userEmail)> GetFriendsAsync(int pageNumber, int pageSize, CancellationToken cancellationToken)
    {
        var userEmail = GetUserEmailFromContext();

        var queryable = friendshipRepository
            .GetQueryable()
            .Where(f => f.Requester.Email == userEmail || f.Recipient.Email == userEmail);

        var totalItems = await queryable.CountAsync(cancellationToken);
        var totalPages = (int)Math.Ceiling(totalItems / (double)pageSize);

        var friends = await queryable
            .AsNoTracking()
            .OrderByDescending(w => w.CreatedAt)
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .Include(f => f.Requester)
            .Include(f => f.Recipient)
            .ToListAsync(cancellationToken);

        return (friends, totalPages, userEmail);
    }

    private async Task<User> GetUserByEmailAsync(string email, CancellationToken cancellationToken)
    {
        var user = await userRepository
            .GetQueryable()
            .Where(u => u.Email == email)
            .FirstOrDefaultAsync(cancellationToken);

        if (user == null)
        {
            throw new NotFoundException("UserNotFound");
        }

        return user;
    }

    private async Task<Friendship?> GetExistingFriendshipAsync(Guid requesterId, Guid recipientId, CancellationToken cancellationToken)
    {
        return await friendshipRepository
            .GetQueryable()
            .Where(f => (f.RequesterId == requesterId && f.RecipientId == recipientId) ||
                        (f.RequesterId == recipientId && f.RecipientId == requesterId))
            .FirstOrDefaultAsync(cancellationToken);
    }

    private async Task<Friendship?> GetExistingFriendshipAsync(Guid friendshipId, CancellationToken cancellationToken)
    {
        return await friendshipRepository
            .GetQueryable()
            .Include(f => f.Recipient)
            .Include(f => f.Requester)
            .FirstOrDefaultAsync(f => f.Id == friendshipId, cancellationToken);
    }

    private string GetUserEmailFromContext() => httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value!;
}
