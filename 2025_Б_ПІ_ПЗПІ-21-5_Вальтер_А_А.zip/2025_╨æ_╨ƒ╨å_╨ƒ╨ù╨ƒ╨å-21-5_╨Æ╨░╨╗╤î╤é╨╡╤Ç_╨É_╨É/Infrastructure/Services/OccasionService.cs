using System.Security.Claims;
using Domain.Exceptions;
using Microsoft.AspNetCore.Http;

namespace Infrastructure.Services;

public class OccasionService(
    IRepository<Occasion> occasionRepository,
    IRepository<User> userRepository,
    IHttpContextAccessor httpContextAccessor,
    IUnitOfWork unitOfWork)
    : IOccasionService
{
    public async Task CreateOccasionAsync(Occasion occasion, CancellationToken cancellationToken)
    {
        var currentUserEmail = GetUserEmailFromContext();

        var currentUser = await userRepository
            .GetQueryable()
            .Where(u => u.Email == currentUserEmail)
            .FirstOrDefaultAsync(cancellationToken) ?? throw new NotFoundException("UserNotFound");


        occasion.UserId = currentUser.Id;

        await occasionRepository.AddAsync(occasion, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteOccasionAsync(Guid id, CancellationToken cancellationToken)
    {
        var occasion = await occasionRepository
            .GetQueryable()
            .Where(o => o.Id == id)
            .FirstOrDefaultAsync(cancellationToken) ?? throw new NotFoundException("OccasionNotFound");

        var currentUserEmail = GetUserEmailFromContext();
        var currentUser = await userRepository
            .GetQueryable()
            .Where(u => u.Email == currentUserEmail)
            .FirstOrDefaultAsync(cancellationToken) ?? throw new NotFoundException("UserNotFound");

        if (occasion.UserId != currentUser.Id)
        {
            throw new ForbiddenException("UnauthorizedOccasionDelete");
        }

        occasionRepository.Delete(occasion);
        await unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task UpdateOccasionAsync(Occasion updatedOccasion, CancellationToken cancellationToken)
    {
        var occasion = await occasionRepository
            .GetQueryable()
            .Where(o => o.Id == updatedOccasion.Id)
            .FirstOrDefaultAsync(cancellationToken)
                       ?? throw new NotFoundException("OccasionNotFound");

        var currentUserEmail = GetUserEmailFromContext();
        var currentUser = await userRepository
            .GetQueryable()
            .Where(u => u.Email == currentUserEmail)
            .FirstOrDefaultAsync(cancellationToken) ?? throw new NotFoundException("UserNotFound");

        if (occasion.UserId != currentUser.Id)
        {
            throw new ForbiddenException("UnauthorizedOccasionUpdate");
        }

        occasion.Name = updatedOccasion.Name;
        occasion.Date = updatedOccasion.Date;

        occasionRepository.Update(occasion);
        await unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task<(IEnumerable<Occasion>, int totalPages)> GetOccasionsByEmailAsync(int pageNumber, int pageSize, CancellationToken cancellationToken)
    {
        var currentUserEmail = GetUserEmailFromContext();
        var currentUser = await userRepository
            .GetQueryable()
            .Where(u => u.Email == currentUserEmail)
            .FirstOrDefaultAsync(cancellationToken) ?? throw new NotFoundException("UserNotFound");

        var queryable = occasionRepository.GetQueryable().Where(o => o.UserId == currentUser.Id);

        var totalItems = await queryable.CountAsync(cancellationToken);
        var totalPages = (int)Math.Ceiling(totalItems / (double)pageSize);

        var occasions = await queryable
            .AsNoTracking()
            .OrderByDescending(o => o.Date)
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);

        return (occasions, totalPages);
    }

    public async Task<Occasion> GetOccasionsByIdAsync(Guid id, CancellationToken cancellationToken)
    {
        var occasion = await occasionRepository
            .GetQueryable()
            .Where(o => o.Id == id)
            .FirstOrDefaultAsync(cancellationToken)
                       ?? throw new NotFoundException("OccasionNotFound");

        var currentUserEmail = GetUserEmailFromContext();
        var currentUser = await userRepository
            .GetQueryable()
            .Where(u => u.Email == currentUserEmail)
            .FirstOrDefaultAsync(cancellationToken) ?? throw new NotFoundException("UserNotFound");

        if (occasion.UserId != currentUser.Id)
        {
            throw new ForbiddenException("UnauthorizedOccasionView");
        }

        return occasion;
    }

    private string GetUserEmailFromContext() => httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value!;
}
