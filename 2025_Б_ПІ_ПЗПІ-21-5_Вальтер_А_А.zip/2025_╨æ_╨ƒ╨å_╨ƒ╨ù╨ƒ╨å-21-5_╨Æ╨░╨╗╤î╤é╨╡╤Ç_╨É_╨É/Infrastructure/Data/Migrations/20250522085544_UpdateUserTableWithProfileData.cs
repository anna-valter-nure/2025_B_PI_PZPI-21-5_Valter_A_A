﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Infrastructure.Data.Migrations
{
    /// <inheritdoc />
    public partial class UpdateUserTableWithProfileData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("03fa2eec-1633-45be-a451-0e0fc393cb63"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("161d54c4-28f8-4f42-bc97-fa54b8581387"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("223e210e-ea14-45c8-af63-39ff778da06d"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("2e9309e0-8e38-4481-b885-b8a43a399fd1"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("32511176-d6b1-457e-8dfd-1b6d0d93f860"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("3bd8dc06-4415-43ac-b090-2ac1d949e64a"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("56a07fbb-d072-404f-a116-84e5c87d64ad"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("571b5b0a-e8a4-4d1d-a6b7-c1a9429395ad"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("5ddeaae8-ffc8-46bf-874d-c6dd8accc206"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("6b6f4dbb-449f-42cb-91df-3366e8d87056"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("6bafbd75-95c1-4761-8438-76a1e4bb1408"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("73561ebe-f844-44b0-80ca-37fd880755d0"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("74a1d509-8247-4791-8df4-251406d9e1b7"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("774e0d1f-fc23-47ed-b2f9-62e107785a7b"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("7c1b1d80-4bb2-4dd1-b55b-e7a9a921ecc1"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("83ff3e49-aef3-4ea1-9710-de7734291cc3"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("91f00248-f704-4f78-bcfe-43fb77e1b098"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("9211dc0e-d365-47e6-97fb-a1f6c5803d52"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("995b8f1f-b095-4d4a-a915-833087a1b71a"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("9bb10b6b-a732-4949-a51c-f086fd54ff9e"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("b6d7f7bf-547d-4c09-a81c-9884d254cd55"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("b84deaee-6ea0-42bc-9e47-2e6c38515e8f"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("bc28e64e-0e38-403a-abc2-f1e35cbd427d"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("d91687d9-aab8-4cc0-bd92-6174d9b87cb9"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("de2e467f-1a69-4e24-a26a-b19b50d97f9d"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("df73da5b-8cf8-4b20-88fc-8bd832305ca0"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("e35b0828-e531-4172-9762-bd774342209c"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("e7442212-4589-470c-9b4b-72a2f0074038"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("eed028a0-ec99-4dfc-9ad8-2efec7f9b770"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("fdf292f4-419d-4abc-8952-bcf6e322c249"));

            migrationBuilder.AddColumn<bool>(
                name: "AllowFriendRequests",
                table: "Users",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "AvatarUrl",
                table: "Users",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Bio",
                table: "Users",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ClothingSize",
                table: "Users",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "DateOfBirth",
                table: "Users",
                type: "timestamp with time zone",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FavoriteColor",
                table: "Users",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Gender",
                table: "Users",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Hobby",
                table: "Users",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "RingSize",
                table: "Users",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ShoeSize",
                table: "Users",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ShowBirthday",
                table: "Users",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "CreatedAt", "CreatedBy", "LastModifiedAt", "LastModifiedBy", "Name", "Type" },
                values: new object[,]
                {
                    { new Guid("1081dc39-3512-4292-b5f3-239c1b1a444a"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5106), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Personal Care", 1 },
                    { new Guid("1f0c4df5-1866-477e-a142-ffe4ad528847"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5115), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Music", 1 },
                    { new Guid("202095f6-3aa4-4430-9ead-5e9add53f4ee"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5091), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Easter", 0 },
                    { new Guid("20c56ba7-9f42-4599-80e6-a0a903a30fdd"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5114), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Wellness", 1 },
                    { new Guid("29b7d751-e690-4ec2-9d2d-d30fba29e784"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5117), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Office", 1 },
                    { new Guid("29c0d5d3-283b-4550-a4a4-52c345ad42c0"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5101), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Home", 1 },
                    { new Guid("2a841119-f3f1-4c34-a88e-c8f7b85e07d6"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5118), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Garden", 1 },
                    { new Guid("347e482f-4583-4ebd-acd9-fc45312f9cdb"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5063), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Birthday", 0 },
                    { new Guid("3e07e852-5fc3-41cb-bf5c-bfe3b42c97ee"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5068), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Wedding", 0 },
                    { new Guid("49384b0d-4f5e-43ab-996e-02c0e9df00c8"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5109), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Jewelry", 1 },
                    { new Guid("4a6c210b-8529-4ee0-85f7-3e04d4ec074b"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5108), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Toys", 1 },
                    { new Guid("4e92e0f6-0490-4ee1-89a0-a52784013913"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5094), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Black Friday", 0 },
                    { new Guid("5312c2ce-8a48-4a5e-96f0-b0070edd3e07"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5112), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Kitchen", 1 },
                    { new Guid("533142ae-4ed9-4414-a852-7a02466619e9"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5095), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Summer Vacation", 0 },
                    { new Guid("75a3f52a-eb42-4f40-9cfa-f9e508d83ceb"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5064), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Christmas", 0 },
                    { new Guid("8bd50d30-50fb-4558-84d7-90b023e157d6"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5102), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Fashion", 1 },
                    { new Guid("993abaa8-cc88-49b2-b1fa-754fd2657937"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5087), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Graduation", 0 },
                    { new Guid("ab1da269-3ce9-4228-9c50-b346f816fa51"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5107), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Sports", 1 },
                    { new Guid("ab5c432b-eccc-49ea-b48e-8e41801a286c"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5119), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Gourmet", 1 },
                    { new Guid("af7230dd-b861-48f0-a095-fad9a2fe305e"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5065), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Anniversary", 0 },
                    { new Guid("b465072a-2f7f-40e7-b234-ff804d51f96d"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5104), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Electronics", 1 },
                    { new Guid("c86871dc-2915-4282-a5eb-f22043d1c990"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5093), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Thanksgiving", 0 },
                    { new Guid("c9b9a09e-ba1b-4570-a356-db77afbf4681"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5067), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Valentine's Day", 0 },
                    { new Guid("cabcc8cf-e4f0-49a8-bdac-93d78015a39b"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5058), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "New Year", 0 },
                    { new Guid("d0370940-2880-443b-b068-94be45112587"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5089), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Retirement", 0 },
                    { new Guid("d60c70ab-1cdb-41a0-861f-8dfea8a14e04"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5069), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Baby Shower", 0 },
                    { new Guid("dd2da547-68b7-45a1-82a5-effd91ee46ff"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5113), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Experiences", 1 },
                    { new Guid("ecce3b8f-75a5-478a-bcb1-464caf2994da"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5092), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Halloween", 0 },
                    { new Guid("f72eaf6b-5aa3-47c0-8f52-dbc90c1ee7d5"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5105), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Books", 1 },
                    { new Guid("fea88d3b-49b7-427a-901a-340db522c327"), new DateTimeOffset(new DateTime(2025, 5, 22, 8, 55, 44, 269, DateTimeKind.Unspecified).AddTicks(5088), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Housewarming", 0 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("1081dc39-3512-4292-b5f3-239c1b1a444a"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("1f0c4df5-1866-477e-a142-ffe4ad528847"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("202095f6-3aa4-4430-9ead-5e9add53f4ee"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("20c56ba7-9f42-4599-80e6-a0a903a30fdd"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("29b7d751-e690-4ec2-9d2d-d30fba29e784"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("29c0d5d3-283b-4550-a4a4-52c345ad42c0"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("2a841119-f3f1-4c34-a88e-c8f7b85e07d6"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("347e482f-4583-4ebd-acd9-fc45312f9cdb"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("3e07e852-5fc3-41cb-bf5c-bfe3b42c97ee"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("49384b0d-4f5e-43ab-996e-02c0e9df00c8"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("4a6c210b-8529-4ee0-85f7-3e04d4ec074b"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("4e92e0f6-0490-4ee1-89a0-a52784013913"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("5312c2ce-8a48-4a5e-96f0-b0070edd3e07"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("533142ae-4ed9-4414-a852-7a02466619e9"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("75a3f52a-eb42-4f40-9cfa-f9e508d83ceb"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("8bd50d30-50fb-4558-84d7-90b023e157d6"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("993abaa8-cc88-49b2-b1fa-754fd2657937"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("ab1da269-3ce9-4228-9c50-b346f816fa51"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("ab5c432b-eccc-49ea-b48e-8e41801a286c"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("af7230dd-b861-48f0-a095-fad9a2fe305e"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("b465072a-2f7f-40e7-b234-ff804d51f96d"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("c86871dc-2915-4282-a5eb-f22043d1c990"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("c9b9a09e-ba1b-4570-a356-db77afbf4681"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("cabcc8cf-e4f0-49a8-bdac-93d78015a39b"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("d0370940-2880-443b-b068-94be45112587"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("d60c70ab-1cdb-41a0-861f-8dfea8a14e04"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("dd2da547-68b7-45a1-82a5-effd91ee46ff"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("ecce3b8f-75a5-478a-bcb1-464caf2994da"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("f72eaf6b-5aa3-47c0-8f52-dbc90c1ee7d5"));

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("fea88d3b-49b7-427a-901a-340db522c327"));

            migrationBuilder.DropColumn(
                name: "AllowFriendRequests",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "AvatarUrl",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Bio",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "ClothingSize",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "DateOfBirth",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "FavoriteColor",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Gender",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "Hobby",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "RingSize",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "ShoeSize",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "ShowBirthday",
                table: "Users");

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "CreatedAt", "CreatedBy", "LastModifiedAt", "LastModifiedBy", "Name", "Type" },
                values: new object[,]
                {
                    { new Guid("03fa2eec-1633-45be-a451-0e0fc393cb63"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2197), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Fashion", 1 },
                    { new Guid("161d54c4-28f8-4f42-bc97-fa54b8581387"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2088), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Birthday", 0 },
                    { new Guid("223e210e-ea14-45c8-af63-39ff778da06d"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2209), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Wellness", 1 },
                    { new Guid("2e9309e0-8e38-4481-b885-b8a43a399fd1"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2213), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Garden", 1 },
                    { new Guid("32511176-d6b1-457e-8dfd-1b6d0d93f860"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2091), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Anniversary", 0 },
                    { new Guid("3bd8dc06-4415-43ac-b090-2ac1d949e64a"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2203), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Toys", 1 },
                    { new Guid("56a07fbb-d072-404f-a116-84e5c87d64ad"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2104), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Halloween", 0 },
                    { new Guid("571b5b0a-e8a4-4d1d-a6b7-c1a9429395ad"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2214), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Gourmet", 1 },
                    { new Guid("5ddeaae8-ffc8-46bf-874d-c6dd8accc206"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2097), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Graduation", 0 },
                    { new Guid("6b6f4dbb-449f-42cb-91df-3366e8d87056"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2093), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Valentine's Day", 0 },
                    { new Guid("6bafbd75-95c1-4761-8438-76a1e4bb1408"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2208), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Experiences", 1 },
                    { new Guid("73561ebe-f844-44b0-80ca-37fd880755d0"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2194), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Home", 1 },
                    { new Guid("74a1d509-8247-4791-8df4-251406d9e1b7"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2205), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Kitchen", 1 },
                    { new Guid("774e0d1f-fc23-47ed-b2f9-62e107785a7b"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2200), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Books", 1 },
                    { new Guid("7c1b1d80-4bb2-4dd1-b55b-e7a9a921ecc1"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2189), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Thanksgiving", 0 },
                    { new Guid("83ff3e49-aef3-4ea1-9710-de7734291cc3"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2090), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Christmas", 0 },
                    { new Guid("91f00248-f704-4f78-bcfe-43fb77e1b098"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2100), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Housewarming", 0 },
                    { new Guid("9211dc0e-d365-47e6-97fb-a1f6c5803d52"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2191), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Summer Vacation", 0 },
                    { new Guid("995b8f1f-b095-4d4a-a915-833087a1b71a"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2201), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Personal Care", 1 },
                    { new Guid("9bb10b6b-a732-4949-a51c-f086fd54ff9e"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2198), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Electronics", 1 },
                    { new Guid("b6d7f7bf-547d-4c09-a81c-9884d254cd55"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2084), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "New Year", 0 },
                    { new Guid("b84deaee-6ea0-42bc-9e47-2e6c38515e8f"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2190), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Black Friday", 0 },
                    { new Guid("bc28e64e-0e38-403a-abc2-f1e35cbd427d"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2095), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Baby Shower", 0 },
                    { new Guid("d91687d9-aab8-4cc0-bd92-6174d9b87cb9"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2211), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Office", 1 },
                    { new Guid("de2e467f-1a69-4e24-a26a-b19b50d97f9d"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2101), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Retirement", 0 },
                    { new Guid("df73da5b-8cf8-4b20-88fc-8bd832305ca0"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2204), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Jewelry", 1 },
                    { new Guid("e35b0828-e531-4172-9762-bd774342209c"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2103), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Easter", 0 },
                    { new Guid("e7442212-4589-470c-9b4b-72a2f0074038"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2210), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Music", 1 },
                    { new Guid("eed028a0-ec99-4dfc-9ad8-2efec7f9b770"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2202), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Sports", 1 },
                    { new Guid("fdf292f4-419d-4abc-8952-bcf6e322c249"), new DateTimeOffset(new DateTime(2025, 2, 28, 10, 38, 28, 847, DateTimeKind.Unspecified).AddTicks(2094), new TimeSpan(0, 0, 0, 0, 0)), "system", new DateTimeOffset(new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new TimeSpan(0, 0, 0, 0, 0)), "system", "Wedding", 0 }
                });
        }
    }
}
