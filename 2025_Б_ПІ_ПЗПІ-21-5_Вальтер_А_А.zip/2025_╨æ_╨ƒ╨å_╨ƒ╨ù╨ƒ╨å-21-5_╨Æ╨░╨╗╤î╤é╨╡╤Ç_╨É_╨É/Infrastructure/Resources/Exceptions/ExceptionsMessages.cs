namespace Infrastructure.Resources.Exceptions;

public class ExceptionsMessages { }
