using Infrastructure.Resources.Exceptions;
using Microsoft.Extensions.Localization;

namespace Infrastructure;

public class ExceptionLocalizer(IStringLocalizer<ExceptionsMessages> localizer) : IExceptionLocalizer
{
    public string GetMessage(string key)
    {
        return localizer[key];
    }
}
